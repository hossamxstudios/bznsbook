<?php

namespace App\Http\Controllers;

use App\Models\Batch;
use App\Models\Project;
use App\Models\Seat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SeatController extends Controller
{
    /**
     * Apply for a project seat
     */
    public function apply(Request $request, Project $project) {
        // Check if the client already applied
        if ($project->clientHasApplied(Auth::user()->client->id)) {
            return redirect()->back()->with('error', 'You have already applied for this project.');
        }
        // Check if the project is accepting applications
        if ($project->status !== Project::STATUS_ACTIVE) {
            return redirect()->back()->with('error', 'This project is not accepting applications at this time.');
        }
        // Find an active batch with available seats
        $batch = Batch::where('project_id', $project->id)->where('is_active', 1)->get()->first(function($batch) {
            return $batch->hasAvailableSeats();
        });
        if (!$batch) {
            return redirect()->back()->with('error', 'No available seats in current batches for this project.');
        }
        // Create a seat for this client
        $seat = new Seat();
        $seat->batch_id = $batch->id;
        $seat->client_id = Auth::user()->client->id;
        $seat->status = 'pending';
        $seat->is_applied = 1;
        $seat->budget_min = $request->input('budget_min');
        $seat->budget_max = $request->input('budget_max');
        $seat->save();

        return redirect()->route('client.projects.show', $project->id)->with('success', 'You have successfully applied for this project.');
    }

    /**
     * Update the status of a seat application
     */
    public function updateStatus(Request $request, Seat $seat)
    {
        $validatedData = $request->validate([
            'status' => 'required|in:pending,contacted,proposal,accepted,rejected',
        ]);

        $seat->status = $validatedData['status'];

        // Update the corresponding flags based on status
        if ($validatedData['status'] === 'contacted') {
            $seat->is_contacted = 1;
        } elseif ($validatedData['status'] === 'proposal') {
            $seat->is_proposal = 1;
        } elseif ($validatedData['status'] === 'accepted') {
            $seat->is_accepted = 1;
            // When a seat is accepted, update the project winner
            $project = $seat->batch->project;
            $project->winner_id = $seat->client_id;
            $project->status = Project::STATUS_AWARDED;
            $project->save();

            // Reject all other applications
            Seat::whereHas('batch', function($query) use ($project) {
                $query->where('project_id', $project->id);
            })
            ->where('id', '!=', $seat->id)
            ->update([
                'status' => 'rejected',
                'is_rejected' => 1
            ]);
        } elseif ($validatedData['status'] === 'rejected') {
            $seat->is_rejected = 1;
        }

        $seat->save();

        return redirect()->back()->with('success', 'Application status updated successfully.');
    }

    /**
     * Cancel an application
     */
    public function cancel(Seat $seat)
    {
        // Check if the authenticated user owns this application
        if (Auth::user('client')->id !== $seat->client_id) {
            return redirect()->back()->with('error', 'You are not authorized to cancel this application.');
        }

        // Check if the application can be cancelled
        if ($seat->is_accepted || $seat->is_rejected) {
            return redirect()->back()->with('error', 'This application cannot be cancelled.');
        }

        $seat->delete();

        return redirect()->back()->with('success', 'Your application has been cancelled.');
    }
}
