<?php

namespace App\Http\Controllers;

use App\Models\Service;
use App\Models\Subcategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ServiceController extends Controller
{
    /**
     * Display a listing of the client's services.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::guard('client')->user();
        $services = $user->services()->paginate(10);
        $subcategories = Subcategory::all();
        
        return view('web.profile-services', compact('services', 'subcategories', 'user'));
    }

    /**
     * Store a newly created service in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'nullable|numeric',
            'duration' => 'nullable|string',
            'subcategories' => 'nullable|array',
            'subcategories.*' => 'exists:subcategories,id',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $user = Auth::guard('client')->user();
        
        $service = new Service();
        $service->name = $request->name;
        $service->details = $request->description; // Map form's description to details column
        $service->price = $request->price;
        $service->client_id = $user->id;
        $service->slug = \Illuminate\Support\Str::slug($request->name);
        
        // Handle skills array from JSON string
        if ($request->has('skills') && !empty($request->skills)) {
            $service->skills = json_decode($request->skills);
        } else {
            $service->skills = [];
        }
        
        $service->level = $request->level ?? null;
        $service->years_experience = $request->years_experience ?? null;
        $service->is_active = 1; // Set active by default
        $service->save();
        
        // Attach subcategories if provided
        if ($request->has('subcategories')) {
            $service->subcategories()->attach($request->subcategories);
        }
        
        return redirect()->route('client.services')
            ->with('success', 'Service created successfully!');
    }

    /**
     * Display the specified service.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = Auth::guard('client')->user();
        $service = $user->services()->with('subcategories')->findOrFail($id);
        
        // Handle AJAX request for service subcategories
        if (request()->ajax() || request()->wantsJson()) {
            $subcategoryIds = $service->subcategories->pluck('id')->toArray();
            return response()->json([
                'service' => $service->only(['id', 'name', 'description', 'price', 'duration']),
                'subcategories' => $subcategoryIds
            ]);
        }
        
        // Regular view request
        $subcategories = Subcategory::all();
        return view('web.profile-service-show', compact('service', 'subcategories', 'user'));
    }

    /**
     * Update the specified service in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'nullable|numeric',
            'duration' => 'nullable|string',
            'subcategories' => 'nullable|array',
            'subcategories.*' => 'exists:subcategories,id',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $user = Auth::guard('client')->user();
        $service = $user->services()->findOrFail($id);
        
        $service->name = $request->name;
        $service->details = $request->description; // Map form's description to details column
        $service->price = $request->price;
        
        // Handle skills array from JSON string
        if ($request->has('skills') && !empty($request->skills)) {
            $service->skills = json_decode($request->skills);
        }
        
        $service->level = $request->level ?? $service->level;
        $service->years_experience = $request->years_experience ?? $service->years_experience;
        $service->save();
        
        // Sync subcategories
        if ($request->has('subcategories')) {
            $service->subcategories()->sync($request->subcategories);
        } else {
            $service->subcategories()->detach();
        }
        
        return redirect()->route('client.services')
            ->with('success', 'Service updated successfully!');
    }

    /**
     * Remove the specified service from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = Auth::guard('client')->user();
        $service = $user->services()->findOrFail($id);
        
        // Detach subcategories before deleting
        $service->subcategories()->detach();
        $service->delete();
        
        return redirect()->route('client.services')
            ->with('success', 'Service deleted successfully!');
    }
}
