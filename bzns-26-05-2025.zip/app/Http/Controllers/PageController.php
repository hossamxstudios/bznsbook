<?php

namespace App\Http\Controllers;

use App\Models\Application;
use App\Models\Career;
use App\Models\Company;
use App\Models\Contact;
use App\Models\Deal;
use App\Models\Lead;
use App\Models\Pipeline;
use App\Models\Candidate;
use App\Models\Service;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Client;

class PageController extends Controller{

    public function firstPage(){
        return view('admin.first');
    }

    public function adminIndex(Request $request){
        $pipeline_select          = $request->pipeline_select;
        if($pipeline_select != 'all' && $pipeline_select != null){
            $the_pipeline         = Pipeline::where('id',$pipeline_select)->get('id');
            $pipeline_select      = Pipeline::find($pipeline_select)->id;
        }elseif($pipeline_select == 'all'){
            $the_pipeline         = Pipeline::get('id');
            $pipeline_select      = 0;
        }else{
            $the_pipeline         = Pipeline::get('id');
            $pipeline_select      = 0;
        }
        $pipelines            = Pipeline::all();
        $startDate            = $request->start_date?? date('Y-m-d', strtotime('first day of january this year'));
        $endDate              = $request->end_date ??now();
        $leads                = Lead::count();
        $contacts             = Contact::count();
        $companies            = Company::count();
        $latest_deals         = Deal::latest()->take(10)->get();
        $latest_companies     = Company::latest()->take(10)->get();
        // Total deals
        $total_deals          = Deal::count();
        // Lost deals
        $lost_deals           = Deal::with('stage')->whereIn('pipeline_id',$the_pipeline)->whereBetween('created_at', [$startDate, $endDate])->whereRelation('stage','percentage', 0)->get();
        $total_lost_amount    = $lost_deals->sum('amount');
        $total_lost_deals     = $lost_deals->count();
        // Won deals
        $won_deals            = Deal::with('stage')->whereIn('pipeline_id',$the_pipeline)->whereBetween('created_at', [$startDate, $endDate])->whereRelation('stage','percentage', 100)->get();
        $total_won_amount     = $won_deals->sum('amount');
        $total_won_deals      = $won_deals->count();
        // Pending deals
        $pending_deals        = Deal::with('stage')->whereIn('pipeline_id',$the_pipeline)->whereBetween('created_at', [$startDate, $endDate])->whereHas('stage', function ($query) {$query->where('percentage', '>', 0)->where('percentage', '<', 100);})->get();
        $total_pending_amount = $pending_deals->sum('amount');
        $total_pending_deals  = $pending_deals->count();
        // Paid and unpaid deals
        $paid_deals           = Deal::with('stage')->whereIn('pipeline_id',$the_pipeline)->whereBetween('created_at', [$startDate, $endDate])->where('is_paid', 1)->count();
        $unpaid_deals         = Deal::with('stage')->whereIn('pipeline_id',$the_pipeline)->whereBetween('created_at', [$startDate, $endDate])->where('is_paid', 0)->count();

        return view('admin.home1', compact('leads','contacts','companies','total_deals','total_lost_deals',
                                    'total_won_deals','total_pending_deals','paid_deals','unpaid_deals','latest_deals',
                                    'latest_companies','total_lost_amount','total_won_amount','total_pending_amount','startDate','endDate','pipelines','pipeline_select','the_pipeline'));

    }

    public function atsIndex(Request $request){
        $startDate            = $request->start_date?? date('Y-m-d', strtotime('first day of january this year'));
        $endDate              = $request->end_date ??now();
        $all_candidates       = Candidate::whereBetween('created_at', [$startDate, $endDate])->count();
        $all_candidates1      = Candidate::whereBetween('created_at', [$startDate, $endDate])->get();
        $all_applications     = Application::whereBetween('created_at', [$startDate, $endDate])->count();
        $all_jobs             = Career::whereBetween('created_at', [$startDate, $endDate])->count();
        $all_jobs1            = Career::whereBetween('created_at', [$startDate, $endDate])->get();
        $total_candidates     = Candidate::count();

        // return $all_candidates1;
        return view('admin.home2', compact('all_candidates','all_applications','all_jobs','total_candidates','startDate','endDate','all_candidates1','all_jobs1'));
    }

    public function companyIndex(Request $request){
        $startDate            = $request->start_date?? date('Y-m-d', strtotime('first day of january this year'));
        $endDate              = $request->end_date ??now();
        $all_candidates       = Candidate::whereBetween('created_at', [$startDate, $endDate])->count();
        $all_candidates1      = Candidate::whereBetween('created_at', [$startDate, $endDate])->get();
        $all_applications     = Application::whereBetween('created_at', [$startDate, $endDate])->count();
        $all_jobs             = Career::whereBetween('created_at', [$startDate, $endDate])->count();
        $all_jobs1            = Career::whereBetween('created_at', [$startDate, $endDate])->get();
        $total_candidates     = Candidate::count();
        return view('company.home1', compact('all_candidates','all_applications','all_jobs','total_candidates','startDate','endDate','all_candidates1','all_jobs1'));


    }

    public function leadForm(){
        $services = Service::all();
        return view('admin.leadForm', compact('services'));
    }

    public function applyLeadForm(Request $request){
        $lead = Lead::where('email', $request->personal_email)->first();
        if (!$lead) {
            $lead = new Lead();
        }
        if($request->personal_email){
            $contact = Contact::where('email', $request->personal_email)->first();
            if (!$contact) {
                $contact    = new Contact();
            }
            $lead->type = "b2c";
            $contact->name  = $request->name;
            $contact->email = $request->personal_email;
            $contact->country_code = $request->country_code;
            $contact->phone = $request->phone;
            $contact->title = $request->job_title;
            $contact->save();
        }
        if($request->company_website && $request->company_name){
            $company = Company::where('website', $request->company_website)->first();
            if (!$company){
                $company      = new Company();
            }
            $lead->type = "b2b";
            $company->name    = $request->company_name;
            $company->website = $request->company_website;
            $company->save();
        }
        $lead->contact_id      = $contact->id;
        $lead->company_id      = $company->id ?? null;
        $lead->name            = $request->name;
        $lead->email           = $request->personal_email;
        $lead->phone           = $request->phone;
        $lead->title           = $request->job_title;
        $lead->source          = 'form';
        $lead->company_name    = $request->company_name;
        $lead->save();
        if($request->services){
            $lead->services()->attach($request->services);
        }
        if($lead->save()){
            return back()->with('success', 'Lead has been submitted successfully');
        }
        return back()->with('error', 'An error occurred while submitting your lead');

    }

    public function homePage(){
        return view('web.home');
    }

    public function pricingPage(){
        return view('web.pricing');
    }

    public function aboutPage(){
        return view('web.about');
    }

    public function contactPage(){
        return view('web.contact');
    }

    public function companiesPage(){
        $clients = Client::all();
        return view('web.companies', compact('clients'));
    }

}
