<!doctype html>
@include('web.main.html')
<head>
    <meta charset="utf-8" />
    <title>My Applications | Bzns Book</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('web.main.meta')
</head>
<body>
    <main class="page-wrapper">
        @include('web.main.navbar')
        <section class="container pt-5">
            <div class="row">
                @include('web.sections.profile.side')
                <div class="col-md-8 mb-lg-4 pt-md-5 mt-n3 mt-md-0">
                    <div class="ps-md-3 ps-lg-0 mt-md-2 8">
                <h1 class="h2 mb-4">My Applications</h1>
                
                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                
                @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                
                <!-- Applications Tab Navigation -->
                <ul class="nav nav-tabs mb-4" id="applicationTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all-applications" type="button" role="tab" aria-controls="all-applications" aria-selected="true">
                            All Applications
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending-applications" type="button" role="tab" aria-controls="pending-applications" aria-selected="false">
                            Pending
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contacted-tab" data-bs-toggle="tab" data-bs-target="#contacted-applications" type="button" role="tab" aria-controls="contacted-applications" aria-selected="false">
                            In Progress
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="accepted-tab" data-bs-toggle="tab" data-bs-target="#accepted-applications" type="button" role="tab" aria-controls="accepted-applications" aria-selected="false">
                            Accepted
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="rejected-tab" data-bs-toggle="tab" data-bs-target="#rejected-applications" type="button" role="tab" aria-controls="rejected-applications" aria-selected="false">
                            Rejected
                        </button>
                    </li>
                </ul>
                
                <div class="tab-content" id="applicationTabsContent">
                    <!-- All Applications Tab -->
                    <div class="tab-pane fade show active" id="all-applications" role="tabpanel" aria-labelledby="all-tab">
                        @if($applications->count() > 0)
                            <div class="table-responsive">
                                <table class="table table-hover align-middle">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col">Project</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Your Budget (EGP)</th>
                                            <th scope="col">Applied</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($applications as $application)
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        @if($application->batch->project->hasMedia('projects'))
                                                            <img src="{{ $application->batch->project->getFirstMediaUrl('projects') }}" alt="{{ $application->batch->project->name }}" class="rounded me-3" width="50" height="50">
                                                        @else
                                                            <div class="bg-light rounded d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                                                <i class="bx bx-briefcase fs-4 text-muted"></i>
                                                            </div>
                                                        @endif
                                                        <div>
                                                            <h6 class="mb-1">
                                                                <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="text-decoration-none text-dark">
                                                                    {{ $application->batch->project->name }}
                                                                </a>
                                                            </h6>
                                                            <p class="mb-0 small text-truncate" style="max-width: 200px;">
                                                                {{ \Illuminate\Support\Str::limit($application->batch->project->details, 40) }}
                                                            </p>
                                                            <span class="badge bg-secondary mt-1">{{ $application->batch->name }}</span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>{!! $application->status_badge !!}</td>
                                                <td>{{ number_format($application->budget_min, 2) }} - {{ number_format($application->budget_max, 2) }}</td>
                                                <td>{{ $application->created_at->format('M d, Y') }}</td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="btn btn-sm btn-outline-primary">
                                                            <i class="bx bx-show"></i> View Project
                                                        </a>
                                                        
                                                        @if(!$application->is_accepted && !$application->is_rejected)
                                                            <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#cancelModal{{ $application->id }}">
                                                                <i class="bx bx-x"></i> Cancel
                                                            </button>
                                                        @endif
                                                    </div>
                                                    
                                                    <!-- Cancel Modal -->
                                                    <div class="modal fade" id="cancelModal{{ $application->id }}" tabindex="-1" aria-labelledby="cancelModalLabel{{ $application->id }}" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="cancelModalLabel{{ $application->id }}">Confirm Cancellation</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    Are you sure you want to cancel your application to "{{ $application->batch->project->name }}"?
                                                                    This action cannot be undone.
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keep Application</button>
                                                                    <form action="{{ route('client.seats.cancel', $application) }}" method="POST">
                                                                        @csrf
                                                                        @method('DELETE')
                                                                        <button type="submit" class="btn btn-danger">Cancel Application</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Pagination -->
                            <div class="mt-4">
                                {{ $applications->links() }}
                            </div>
                        @else
                            <div class="p-4 text-center rounded border">
                                <i class="mb-2 display-6 bx bx-search-alt text-muted"></i>
                                <p class="mb-3">You haven't applied to any projects yet.</p>
                                <a href="{{ route('projects.index') }}" class="btn btn-primary">
                                    <i class="bx bx-search me-2"></i>Browse Projects
                                </a>
                            </div>
                        @endif
                    </div>
                    
                    <!-- Pending Applications Tab -->
                    <div class="tab-pane fade" id="pending-applications" role="tabpanel" aria-labelledby="pending-tab">
                        @if($pendingApplications->count() > 0)
                            <div class="row g-4">
                                @foreach($pendingApplications as $application)
                                    <div class="col-md-6">
                                        <div class="card card-hover h-100 border-0 shadow-sm">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center mb-3">
                                                    <h2 class="h5 mb-0">
                                                        <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="text-decoration-none text-dark">
                                                            {{ $application->batch->project->name }}
                                                        </a>
                                                    </h2>
                                                    <span class="badge bg-warning text-dark">Pending</span>
                                                </div>
                                                
                                                <p class="fs-sm text-body mb-3">
                                                    {{ \Illuminate\Support\Str::limit($application->batch->project->details, 100) }}
                                                </p>
                                                
                                                <div class="d-flex flex-wrap gap-2 mb-3">
                                                    <span class="badge bg-faded-primary text-primary">
                                                        <i class="bx bx-money me-1"></i> Your Offer: {{ number_format($application->budget_min, 2) }} - {{ number_format($application->budget_max, 2) }} EGP
                                                    </span>
                                                    
                                                    <span class="badge bg-faded-info text-info">
                                                        <i class="bx bx-time me-1"></i> Applied {{ $application->created_at->diffForHumans() }}
                                                    </span>
                                                </div>
                                                
                                                <div class="d-flex justify-content-between border-top pt-3">
                                                    <span class="text-muted small">Batch: {{ $application->batch->name }}</span>
                                                    
                                                    <div>
                                                        <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="btn btn-sm btn-primary me-2">
                                                            <i class="bx bx-show me-1"></i> View
                                                        </a>
                                                        <form action="{{ route('client.seats.cancel', $application) }}" method="POST" class="d-inline">
                                                            @csrf
                                                            @method('DELETE')
                                                            <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to cancel this application?')">
                                                                <i class="bx bx-x me-1"></i> Cancel
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="p-4 text-center rounded border">
                                <i class="mb-2 display-6 bx bx-info-circle text-muted"></i>
                                <p class="mb-0">You don't have any pending applications at the moment.</p>
                            </div>
                        @endif
                    </div>
                    
                    <!-- In Progress Applications Tab -->
                    <div class="tab-pane fade" id="contacted-applications" role="tabpanel" aria-labelledby="contacted-tab">
                        @if($inProgressApplications->count() > 0)
                            <div class="row g-4">
                                @foreach($inProgressApplications as $application)
                                    <div class="col-md-6">
                                        <div class="card card-hover h-100 border-0 shadow-sm">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center mb-3">
                                                    <h2 class="h5 mb-0">
                                                        <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="text-decoration-none text-dark">
                                                            {{ $application->batch->project->name }}
                                                        </a>
                                                    </h2>
                                                    
                                                    @if($application->status === 'contacted')
                                                        <span class="badge bg-info">Contacted</span>
                                                    @elseif($application->status === 'proposal')
                                                        <span class="badge bg-primary">Proposal</span>
                                                    @endif
                                                </div>
                                                
                                                <p class="fs-sm text-body mb-3">
                                                    {{ \Illuminate\Support\Str::limit($application->batch->project->details, 100) }}
                                                </p>
                                                
                                                <div class="d-flex flex-wrap gap-2 mb-3">
                                                    <span class="badge bg-faded-primary text-primary">
                                                        <i class="bx bx-money me-1"></i> Your Offer: {{ number_format($application->budget_min, 2) }} - {{ number_format($application->budget_max, 2) }} EGP
                                                    </span>
                                                    
                                                    <span class="badge bg-faded-info text-info">
                                                        <i class="bx bx-time me-1"></i> Last Updated: {{ $application->updated_at->diffForHumans() }}
                                                    </span>
                                                </div>
                                                
                                                <div class="alert alert-info mb-3">
                                                    <i class="bx bx-info-circle me-1"></i>
                                                    @if($application->status === 'contacted')
                                                        The client has contacted you about your application!
                                                    @elseif($application->status === 'proposal')
                                                        Your proposal is being reviewed by the client.
                                                    @endif
                                                </div>
                                                
                                                <div class="d-flex justify-content-between border-top pt-3">
                                                    <span class="text-muted small">Batch: {{ $application->batch->name }}</span>
                                                    
                                                    <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="btn btn-sm btn-primary">
                                                        <i class="bx bx-show me-1"></i> View Project
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="p-4 text-center rounded border">
                                <i class="mb-2 display-6 bx bx-info-circle text-muted"></i>
                                <p class="mb-0">You don't have any in-progress applications at the moment.</p>
                            </div>
                        @endif
                    </div>
                    
                    <!-- Accepted Applications Tab -->
                    <div class="tab-pane fade" id="accepted-applications" role="tabpanel" aria-labelledby="accepted-tab">
                        @if($acceptedApplications->count() > 0)
                            <div class="row g-4">
                                @foreach($acceptedApplications as $application)
                                    <div class="col-md-6">
                                        <div class="card card-hover h-100 border-0 shadow-sm">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center mb-3">
                                                    <h2 class="h5 mb-0">
                                                        <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="text-decoration-none text-dark">
                                                            {{ $application->batch->project->name }}
                                                        </a>
                                                    </h2>
                                                    <span class="badge bg-success">Accepted</span>
                                                </div>
                                                
                                                <p class="fs-sm text-body mb-3">
                                                    {{ \Illuminate\Support\Str::limit($application->batch->project->details, 100) }}
                                                </p>
                                                
                                                <div class="d-flex flex-wrap gap-2 mb-3">
                                                    <span class="badge bg-faded-primary text-primary">
                                                        <i class="bx bx-money me-1"></i> Your Offer: {{ number_format($application->budget_min, 2) }} - {{ number_format($application->budget_max, 2) }} EGP
                                                    </span>
                                                    
                                                    <span class="badge bg-faded-success text-success">
                                                        <i class="bx bx-check-circle me-1"></i> Accepted: {{ $application->updated_at->format('M d, Y') }}
                                                    </span>
                                                </div>
                                                
                                                <div class="alert alert-success mb-3">
                                                    <i class="bx bx-check-double me-1"></i>
                                                    @if($application->batch->project->winner && $application->batch->project->winner->id === $application->client_id)
                                                        Congratulations! You have been selected as the winner for this project!
                                                    @else
                                                        Your application has been accepted by the client!
                                                    @endif
                                                </div>
                                                
                                                <div class="d-flex justify-content-between border-top pt-3">
                                                    <span class="text-muted small">Batch: {{ $application->batch->name }}</span>
                                                    
                                                    <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="btn btn-sm btn-primary">
                                                        <i class="bx bx-show me-1"></i> View Project
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="p-4 text-center rounded border">
                                <i class="mb-2 display-6 bx bx-info-circle text-muted"></i>
                                <p class="mb-0">You don't have any accepted applications at the moment.</p>
                            </div>
                        @endif
                    </div>
                    
                    <!-- Rejected Applications Tab -->
                    <div class="tab-pane fade" id="rejected-applications" role="tabpanel" aria-labelledby="rejected-tab">
                        @if($rejectedApplications->count() > 0)
                            <div class="row g-4">
                                @foreach($rejectedApplications as $application)
                                    <div class="col-md-6">
                                        <div class="card card-hover h-100 border-0 shadow-sm">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center mb-3">
                                                    <h2 class="h5 mb-0">
                                                        <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="text-decoration-none text-dark">
                                                            {{ $application->batch->project->name }}
                                                        </a>
                                                    </h2>
                                                    <span class="badge bg-danger">Rejected</span>
                                                </div>
                                                
                                                <p class="fs-sm text-body mb-3">
                                                    {{ \Illuminate\Support\Str::limit($application->batch->project->details, 100) }}
                                                </p>
                                                
                                                <div class="d-flex flex-wrap gap-2 mb-3">
                                                    <span class="badge bg-faded-primary text-primary">
                                                        <i class="bx bx-money me-1"></i> Your Offer: {{ number_format($application->budget_min, 2) }} - {{ number_format($application->budget_max, 2) }} EGP
                                                    </span>
                                                    
                                                    <span class="badge bg-faded-danger text-danger">
                                                        <i class="bx bx-x-circle me-1"></i> Rejected: {{ $application->updated_at->format('M d, Y') }}
                                                    </span>
                                                </div>
                                                
                                                <div class="alert alert-secondary mb-3">
                                                    <i class="bx bx-info-circle me-1"></i>
                                                    Your application was not selected for this project. Keep applying to other opportunities!
                                                </div>
                                                
                                                <div class="d-flex justify-content-between border-top pt-3">
                                                    <span class="text-muted small">Batch: {{ $application->batch->name }}</span>
                                                    
                                                    <a href="{{ route('projects.show', $application->batch->project->slug) }}" class="btn btn-sm btn-outline-primary">
                                                        <i class="bx bx-show me-1"></i> View Project
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="p-4 text-center rounded border">
                                <i class="mb-2 display-6 bx bx-info-circle text-muted"></i>
                                <p class="mb-0">You don't have any rejected applications at the moment.</p>
                            </div>
                        @endif
                    </div>
                    </div>
                </div>
            </div>
        </section>
        @include('web.main.footer')
    </main>
    @include('web.main.scripts')
</body>
</html>
