<section class="container pb-md-4 pb-lg-5">
    <h1 class="pb-4">Our Services</h1>
    <div class="row">
        <!-- Item -->
        <div class="py-4 my-2 col-md-4">
            <a href="#" class="pt-5 border-0 shadow-sm card card-hover h-100 text-decoration-none px-sm-3 px-md-0 px-lg-3 pb-sm-3 pb-md-0 pb-lg-3 me-xl-2">
            <div class="pt-3 card-body">
                <div class="top-0 p-3 d-inline-block bg-dark shadow-primary rounded-3 position-absolute translate-middle-y">
                <img src="assets/img/services/icons/cms.svg" class="m-1 d-block" width="40" alt="Icon">
                </div>
                <h2 class="h4 d-inline-flex align-items-center">
                Custom Software Development
                <i class="bx bx-right-arrow-circle text-primary fs-3 ms-2"></i>
                </h2>
                <p class="mb-0 fs-sm text-body">Nisi, dis sed cursus eget pellentesque mattis. Odio eu proin aliquam a. Semper bibendum tellus non tellus, facilisi dignissim in quam massa. Aliquam, feugiat ut cum tellus, sit. Quis consectetur gravida ac ac lectus cursus egestas.</p>
            </div>
            </a>
        </div>
        <!-- Item -->
        <div class="py-4 my-2 col-md-4 my-sm-3">
            <a href="#" class="pt-5 border-0 shadow-sm card card-hover h-100 text-decoration-none px-sm-3 px-md-0 px-lg-3 pb-sm-3 pb-md-0 pb-lg-3 ms-xl-2">
            <div class="pt-3 card-body">
                <div class="top-0 p-3 d-inline-block bg-dark shadow-dark rounded-3 position-absolute translate-middle-y">
                <img src="assets/img/services/icons/rocket.svg" class="m-1 d-block" width="40" alt="Icon">
                </div>
                <h2 class="h4 d-inline-flex align-items-center">
                Software Integration
                <i class="bx bx-right-arrow-circle text-primary fs-3 ms-2"></i>
                </h2>
                <p class="mb-0 fs-sm text-body">Id eget blandit sapien cras massa lectus lorem placerat. Quam dolor commodo fermentum bibendum dictumst. Risus pretium eget at viverra eget. Sit neque adipiscing malesuada blandit justo, quam.</p>
            </div>
            </a>
        </div>
        <!-- Item -->
        <div class="py-4 my-2 col-md-4 my-sm-3">
            <a href="#" class="pt-5 border-0 shadow-sm card card-hover h-100 text-decoration-none px-sm-3 px-md-0 px-lg-3 pb-sm-3 pb-md-0 pb-lg-3 ms-xl-2">
            <div class="pt-3 card-body">
                <div class="top-0 p-3 d-inline-block bg-dark shadow-dark rounded-3 position-absolute translate-middle-y">
                <img src="assets/img/services/icons/mobile-app.svg" class="m-1 d-block" width="40" alt="Icon">
                </div>
                <h2 class="h4 d-inline-flex align-items-center">
                Mobile App Development
                <i class="bx bx-right-arrow-circle text-primary fs-3 ms-2"></i>
                </h2>
                <p class="mb-0 fs-sm text-body">Nunc, justo, diam orci, dictum purus convallis risus. Suscipit hendrerit at egestas id id blandit interdum est. Integer fames placerat turpis pretium quis hac leo lacus. Orci, dictum nunc mus quis semper eu bibendum enim, morbi.</p>
            </div>
            </a>
        </div>
    </div>
</section>