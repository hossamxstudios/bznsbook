<section class="container-fluid">
    <div class="px-3 py-5 bg-secondary rounded-3 px-sm-4 px-lg-0">
      <div class="pt-1 pb-2 row align-items-center py-lg-4">
        <div class="pb-3 mb-4 col-xl-4 col-lg-5 col-md-6 offset-lg-1 mb-md-0 pb-md-0">
          <h2 class="h1 mb-lg-4">Get in Touch</h2>
          <p class="pb-2 pb-md-4 pb-lg-5">Have a project in mind? To request a quote contact us directly or fill out the form and let us know how we can help.</p>
          <h3 class="mb-lg-4">Contact Info</h3>
          <ul class="pb-3 mb-2 list-unstyled pb-md-4 pb-lg-5">
            <li class="mb-2">
              <a href="tel:4065550120" class="p-0 nav-link d-flex align-items-center">
                <i class="bx bx-phone-call fs-xl text-primary me-2"></i>
                (406)&nbsp;555&#8209;0120
              </a>
            </li>
            <li class="mb-2">
              <a href="mailto:example@email.com" class="p-0 nav-link d-flex align-items-center">
                <i class="bx bx-envelope fs-xl text-primary me-2"></i>
                example@email.com
              </a>
            </li>
            <li class="mb-2">
              <a href="#" class="p-0 nav-link d-flex align-items-center">
                <i class="bx bx-map fs-xl text-primary me-2"></i>
                2464 Royal Ln. Mesa,New Jersey 45463
              </a>
            </li>
          </ul>
          <div class="d-flex">
            <a href="#" class="btn btn-icon btn-outline-secondary btn-facebook me-3" aria-label="Facebook">
              <i class="bx bxl-facebook"></i>
            </a>
            <a href="#" class="btn btn-icon btn-outline-secondary btn-twitter me-3" aria-label="Twitter">
              <i class="bx bxl-twitter"></i>
            </a>
            <a href="#" class="btn btn-icon btn-outline-secondary btn-linkedin me-3" aria-label="LinkedIn">
              <i class="bx bxl-linkedin"></i>
            </a>
            <a href="#" class="btn btn-icon btn-outline-secondary btn-instagram" aria-label="Instagram">
              <i class="bx bxl-instagram"></i>
            </a>
          </div>
        </div>
        <div class="col-lg-5 col-md-6 offset-xl-1">
          <div class="border-0 shadow-sm card p-sm-2">
            <form class="card-body needs-validation" novalidate>
              <div class="mb-4">
                <label for="service" class="form-label fs-base">Service</label>
                <select id="service" class="form-select form-select-lg" required>
                  <option value="" selected disabled>Choose the service you are interested in</option>
                  <option value="Custom Software Development">Custom Software Development</option>
                  <option value="Software Integration">Software Integration</option>
                  <option value="Mobile App Development">Mobile App Development</option>
                  <option value="Business Analytics">Business Analytics</option>
                  <option value="Software Testing">Software Testing</option>
                  <option value="Project Management">Project Management</option>
                </select>
                <div class="invalid-feedback">Please choose the service!</div>
              </div>
              <div class="mb-4">
                <label for="name" class="form-label fs-base">Full name</label>
                <input type="text" id="name" class="form-control form-control-lg" required>
                <div class="invalid-feedback">Please enter your name!</div>
              </div>
              <div class="mb-4">
                <label for="email" class="form-label fs-base">Email address</label>
                <input type="email" id="email" class="form-control form-control-lg" required>
                <div class="invalid-feedback">Please provide a valid email address!</div>
              </div>
              <div class="pb-2 mb-4">
                <label for="message" class="form-label fs-base">Email address</label>
                <textarea id="message" class="form-control form-control-lg" rows="3" placeholder="Tell us about your project" required></textarea>
                <div class="invalid-feedback">Please enter you message!</div>
              </div>
              <button type="submit" class="btn btn-primary shadow-primary btn-lg">Send request</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>