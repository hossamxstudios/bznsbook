
   <!-- Hero section with layer parallax gfx -->
   <section class="py-5 position-relative">

    <!-- Gradient BG -->
    <div class="top-0 opacity-10 position-absolute start-0 w-100 h-100" style="background:linear-gradient(90deg, #000000 0%, #ffffff 70%, #00000091 100%) !important;"></div>

    <!-- Content -->
    <div class="container position-relative zindex-2 py-lg-4">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column pt-lg-4 pt-xl-5">
          <h5 class="my-2">Welcome!</h5>
          <h1 class="mb-4 display-3">Find The  <span class="text-primary">Best Partner </span> with No Limits</h1>
          <p class="mb-5 fs-lg">Enjoy our great selection of Premium companies from all over the world. Choose from more than 25K business partner and expand your business now!</p>

          <!-- Desktop form -->
          <form class="mb-5 d-none d-sm-flex">
            <div class="input-group d-block d-sm-flex input-group-lg me-3">
              <input type="text" class="form-control w-50" placeholder="Search Service...">
              <select class="form-select w-50">
                <option value="" selected disabled>Categories</option>
                <option value="Web Development">Web Development</option>
                <option value="Mobile Development">Mobile Development</option>
                <option value="Programming">Programming</option>
                <option value="Game Development">Game Development</option>
                <option value="Software Testing">Software Testing</option>
                <option value="Software Engineering">Software Engineering</option>
                <option value="Network & Security">Network &amp; Security</option>
              </select>
            </div>
            <button type="submit" class="btn btn-icon btn-primary btn-lg" aria-label="Search">
              <i class="bx bx-search"></i>
            </button>
          </form>

          <!-- Mobile form -->
          <form class="mb-5 d-sm-none">
            <input type="text" class="mb-2 form-control form-control-lg" placeholder="Search courses...">
            <select class="mb-2 form-select form-select-lg">
              <option value="" selected disabled>Categories</option>
              <option value="Web Development">Web Development</option>
              <option value="Mobile Development">Mobile Development</option>
              <option value="Programming">Programming</option>
              <option value="Game Development">Game Development</option>
              <option value="Software Testing">Software Testing</option>
              <option value="Software Engineering">Software Engineering</option>
              <option value="Network & Security">Network &amp; Security</option>
            </select>
            <button type="submit" class="btn btn-icon btn-primary btn-lg w-100 d-sm-none" aria-label="Search">
              <i class="bx bx-search"></i>
            </button>
          </form>
          <div class="pb-4 mt-auto mb-3 d-flex align-items-center mb-lg-0 pb-lg-0 pb-xl-5">
            <div class="d-flex me-3">
              <div class="d-flex align-items-center justify-content-center bg-light rounded-circle" style="width: 52px; height: 52px;">
                <img src="assets/img/avatar/08.jpg" class="rounded-circle" width="48" alt="Avatar">
              </div>
              <div class="d-flex align-items-center justify-content-center bg-light rounded-circle ms-n3" style="width: 52px; height: 52px;">
                <img src="assets/img/avatar/15.jpg" class="rounded-circle" width="48" alt="Avatar">
              </div>
              <div class="d-flex align-items-center justify-content-center bg-light rounded-circle ms-n3" style="width: 52px; height: 52px;">
                <img src="assets/img/avatar/16.jpg" class="rounded-circle" width="48" alt="Avatar">
              </div>
            </div>
            <span class="fs-sm"><span class="text-primary fw-semibold">10K+</span> Companies are already with us</span>
          </div>
        </div>
        <div class="col-lg-6">

          <!-- Parallax gfx -->
          <div class="mx-auto parallax me-lg-0" style="max-width: 648px;">
            <div class="parallax-layer" data-depth="0.1">
              <img src="assets/img/landing/online-courses/hero/layer01.png" alt="Layer">
            </div>
            <div class="parallax-layer" data-depth="0.13">
              <img src="assets/img/landing/online-courses/hero/layer02.png" alt="Layer">
            </div>
            <div class="parallax-layer zindex-5" data-depth="-0.12">
              <img src="assets/img/landing/online-courses/hero/layer03.png" alt="Layer">
            </div>
            <div class="parallax-layer zindex-3" data-depth="0.27">
              <img src="assets/img/landing/online-courses/hero/layer04.png" alt="Layer">
            </div>
            <div class="parallax-layer zindex-1" data-depth="-0.18">
              <img src="assets/img/landing/online-courses/hero/layer05.png" alt="Layer">
            </div>
            <div class="parallax-layer zindex-1" data-depth="0.1">
              <img src="assets/img/landing/online-courses/hero/layer06.png" alt="Layer">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
