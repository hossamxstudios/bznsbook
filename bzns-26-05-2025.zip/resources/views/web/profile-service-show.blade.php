<!doctype html>
@include('web.main.html')
<head>
    <meta charset="utf-8" />
    <title>{{ $service->name }} - Bzns Book</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('web.main.meta')
</head>
<body>
    <main class="page-wrapper">
        @include('web.main.navbar')
        <section class="container pt-5">
            <div class="row">
                @include('web.sections.profile.side')

                <div class="col-lg-9">
                    <!-- Header with breadcrumb and back button -->
                    <div class="mb-4 d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="mb-2 fw-bold">Service Details</h4>
                            <nav aria-label="breadcrumb">
                                <ol class="mb-0 breadcrumb">
                                    <li class="breadcrumb-item"><a href="/profile"><i class="bx bx-home-alt me-1"></i>Dashboard</a></li>
                                    <li class="breadcrumb-item"><a href="{{ route('client.services') }}">Services</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">{{ \Illuminate\Support\Str::limit($service->name, 30) }}</li>
                                </ol>
                            </nav>
                        </div>
                        <a href="{{ route('client.services') }}" class="shadow-sm btn btn-outline-primary portfolio-action-btn">
                            <i class="bx bx-arrow-back me-2"></i> Back to Services
                        </a>
                    </div>

                    <!-- Service Header Section -->
                    <div class="p-4 mb-4 border bg-light rounded-3">
                        <div class="row align-items-center">
                            <div class="mb-3 col-lg-8 mb-lg-0">

                                <h1 class="h2"><i class="align-middle bx bx-cog text-primary"></i> {{ $service->name }}</h1>

                                <!-- Service Metadata Tags -->
                                <div class="flex-wrap gap-2 mb-3 d-flex">
                                    @if($service->years_experience)
                                        <span class="px-3 py-2 btn btn-outline-primary rounded-pill">
                                            <i class="bx bx-time me-1"></i> {{ $service->years_experience }} years experience
                                        </span>
                                    @endif

                                    @if($service->price)
                                        <span class="px-3 py-2 btn btn-outline-primary rounded-pill">
                                            <i class="bx bx-money me-1"></i> {{ number_format($service->price, 2) }} EGP
                                        </span>
                                    @endif

                                    @if($service->level)
                                        <span class="px-3 py-2 btn btn-outline-primary rounded-pill">
                                            <i class="bx bx-star me-1"></i>
                                            @for($i = 1; $i <= 5; $i++)
                                                @if($i <= $service->level)
                                                    <i class="bx bxs-star text-dark"></i>
                                                @else
                                                    <i class="bx bx-star text-muted"></i>
                                                @endif
                                            @endfor
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="p-3 bg-white rounded border">
                                    <div class="mb-3 d-flex align-items-center">
                                        <div class="me-2 text-primary"><i class="bx bx-category fs-5"></i></div>
                                        <div>
                                            <div class="text-muted small">Subcategories</div>
                                            <div class="fw-medium">{{ $service->subcategories->count() }} associated</div>
                                        </div>
                                    </div>

                                    <div class="d-flex align-items-center">
                                        <div class="me-2 text-primary"><i class="bx bx-calendar fs-5"></i></div>
                                        <div>
                                            <div class="text-muted small">Added On</div>
                                            <div class="fw-medium">{{ $service->created_at->format('M d, Y') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Service Details and Description -->
                    <div class="mb-4 border-0 shadow-sm card">
                        <div class="py-3 bg-white card-header d-flex justify-content-between align-items-center">
                            <h3 class="mb-0 h5"><i class="bx bx-info-circle text-primary me-2"></i> Service Details</h3>
                            <div>
                                <button type="button" class="btn btn-sm btn-primary edit-service" data-bs-toggle="modal" data-bs-target="#editServiceModal" data-id="{{ $service->id }}" data-name="{{ $service->name }}" data-description="{{ $service->details }}" data-price="{{ $service->price }}" data-years_experience="{{ $service->years_experience }}" data-skills="{{ json_encode($service->skills) }}">
                                    <i class="bx bx-edit me-1"></i> Edit
                                </button>
                                <form class="d-inline delete-form" method="POST" action="{{ route('client.services.delete', $service->id) }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="bx bx-trash me-1"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                        <div class="p-4 card-body">
                            @if($service->details)
                                <p class="mb-4 lead">{{ $service->details }}</p>
                            @else
                                <div class="mb-4 border alert alert-light">
                                    <i class="bx bx-info-circle me-2"></i> No detailed description provided for this service.
                                </div>
                            @endif

                            @if(is_array($service->skills) && count($service->skills) > 0)
                                <div class="mb-4">
                                    <h4 class="mb-3 h5">Skills & Expertise</h4>
                                    <div class="flex-wrap gap-2 d-flex">
                                        @foreach($service->skills as $skill)
                                            <span class="px-3 py-2 btn btn-outline-primary rounded-pill">
                                                <i class="bx bx-check-circle me-1"></i> {{ $skill }}
                                            </span>
                                        @endforeach
                                    </div>
                                </div>
                            @endif

                            <!-- Subcategories Section -->
                            <div class="mt-4 border-0 shadow-sm card">
                                <div class="py-3 bg-white card-header d-flex justify-content-between align-items-center">
                                    <h3 class="mb-0 h5"><i class="bx bx-category text-primary me-2"></i> Subcategories</h3>
                                </div>
                                <div class="p-4 card-body">
                                    @if($service->subcategories->count() > 0)
                                        <div class="flex-wrap gap-2 d-flex">
                                            @foreach($service->subcategories as $subcategory)
                                                <span class="px-3 py-2 border badge bg-light text-dark rounded-pill">
                                                    <i class="bx bx-check-circle text-primary me-1"></i> {{ $subcategory->name }}
                                                </span>
                                            @endforeach
                                        </div>
                                    @else
                                        <div class="text-muted fst-italic">
                                            <i class="bx bx-info-circle me-1"></i> No subcategories associated with this service.
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        @include('web.main.footer')
    </main>
    @include('web.main.scripts')

    <!-- Edit Service Modal -->
    <div class="modal fade" id="editServiceModal" tabindex="-1" aria-labelledby="editServiceModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form id="editServiceForm" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="modal-header">
                        <h5 class="modal-title" id="editServiceModalLabel">Edit Service</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Basic Info Section -->
                        <h6 class="mb-3 fw-bold">Basic Information</h6>
                        <div class="mb-3">
                            <label for="edit_name" class="form-label">Service Name</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" id="edit_name" name="name" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="edit_description" class="form-label">Description</label>
                            <textarea class="form-control @error('description') is-invalid @enderror" id="edit_description" name="description" rows="3"></textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3 row">
                            <div class="col-md-6">
                                <label for="edit_price" class="form-label">Price (EGP)</label>
                                <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="edit_price" name="price">
                                @error('price')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="edit_years_experience" class="form-label">Years of Experience</label>
                                <input type="number" class="form-control @error('years_experience') is-invalid @enderror" id="edit_years_experience" name="years_experience">
                                @error('years_experience')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="edit_skills" class="form-label">Skills (press Enter after each skill)</label>
                            <div class="skills-input-container">
                                <input type="text" class="form-control skills-input" id="edit-skills-input" placeholder="Add skills...">
                                <div class="mt-2 skills-tags" id="edit-skills-tags"></div>
                                <input type="hidden" name="skills" id="edit-skills-hidden">
                            </div>
                            <small class="text-muted">Enter skills related to this service (e.g. WordPress, JavaScript, Marketing)</small>
                        </div>

                        <!-- Subcategories Section -->
                        <h6 class="mb-3 fw-bold">Subcategories</h6>
                        <div class="mb-3">
                            <label class="form-label">Select Subcategories</label>
                            @if($subcategories->count() > 0)
                                <div class="row">
                                    @foreach($subcategories as $subcategory)
                                        <div class="mb-2 col-md-4">
                                            <div class="form-check">
                                                <input class="form-check-input edit-subcategory-checkbox" type="checkbox" name="subcategories[]" value="{{ $subcategory->id }}" id="edit_subcategory{{ $subcategory->id }}" {{ $service->subcategories->contains($subcategory->id) ? 'checked' : '' }}>
                                                <label class="form-check-label" for="edit_subcategory{{ $subcategory->id }}">
                                                    {{ $subcategory->name }}
                                                </label>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="alert alert-info">
                                    <i class="bx bx-info-circle me-1"></i> No subcategories available. You can update this service without subcategories.
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Service</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<style>
    .skills-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
    }
    .skill-tag {
        background-color: #e9ecef;
        border: 1px solid #ced4da;
        border-radius: 0.25rem;
        padding: 0.25rem 0.5rem;
        display: inline-flex;
        align-items: center;
        margin-right: 0.5rem;
        margin-bottom: 0.5rem;
    }
    .skill-tag .remove-tag {
        margin-left: 0.5rem;
        cursor: pointer;
        color: #dc3545;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Skills tag input functionality for Edit form
        const editSkillsInput = document.getElementById('edit-skills-input');
        const editSkillsTags = document.getElementById('edit-skills-tags');
        const editSkillsHidden = document.getElementById('edit-skills-hidden');
        let editSkills = [];

        function updateEditSkillsHidden() {
            editSkillsHidden.value = JSON.stringify(editSkills);
        }

        function addEditSkill(skill) {
            if (skill && !editSkills.includes(skill)) {
                editSkills.push(skill);
                updateEditSkillsHidden();

                const tagElement = document.createElement('div');
                tagElement.className = 'skill-tag';
                tagElement.innerHTML = `
                    <span>${skill}</span>
                    <span class="remove-tag"><i class="bx bx-x"></i></span>
                `;

                tagElement.querySelector('.remove-tag').addEventListener('click', function() {
                    const index = editSkills.indexOf(skill);
                    if (index !== -1) {
                        editSkills.splice(index, 1);
                        updateEditSkillsHidden();
                        tagElement.remove();
                    }
                });

                editSkillsTags.appendChild(tagElement);
            }
        }

        if (editSkillsInput) {
            editSkillsInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    const skill = this.value.trim();
                    if (skill) {
                        addEditSkill(skill);
                        this.value = '';
                    }
                }
            });
        }

        // Handle edit service button
        document.querySelector('.edit-service').addEventListener('click', function() {
            const serviceId = this.getAttribute('data-id');
            const serviceName = this.getAttribute('data-name');
            const serviceDescription = this.getAttribute('data-description'); // This is actually details
            const servicePrice = this.getAttribute('data-price');
            const serviceYearsExperience = this.getAttribute('data-years_experience');
            const serviceSkills = this.getAttribute('data-skills');

            // Reset edit skills
            editSkills = [];
            editSkillsTags.innerHTML = '';

            // Set form action
            document.getElementById('editServiceForm').setAttribute('action', `/profile/services/${serviceId}`);

            // Set form values
            document.getElementById('edit_name').value = serviceName;
            document.getElementById('edit_description').value = serviceDescription;
            document.getElementById('edit_price').value = servicePrice;
            document.getElementById('edit_years_experience').value = serviceYearsExperience;

            // Parse and set skills
            if (serviceSkills) {
                try {
                    const skillsArray = JSON.parse(serviceSkills);
                    if (Array.isArray(skillsArray)) {
                        skillsArray.forEach(skill => addEditSkill(skill));
                    }
                } catch (e) {
                    console.error('Error parsing skills:', e);
                }
            }
        });

        // Handle delete confirmation
        document.querySelector('.delete-form').addEventListener('submit', function(e) {
            if (!confirm('Are you sure you want to delete this service? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });
</script>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        // Profile picture upload functionality
        const changePictureBtn = document.getElementById('change-picture-btn');
        const profilePictureInput = document.getElementById('profile-picture-input');
        const profilePictureForm = document.getElementById('profile-picture-form');

        if (changePictureBtn && profilePictureInput && profilePictureForm) {
          changePictureBtn.addEventListener('click', function() {
            profilePictureInput.click();
          });

          profilePictureInput.addEventListener('change', function() {
            if (profilePictureInput.files.length > 0) {
              profilePictureForm.submit();
            }
          });
        }
      });
    </script>
</body>
</html>
