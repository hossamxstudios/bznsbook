<!doctype html>
@include('web.main.html')
<head>
    <meta charset="utf-8" />
    <title>My Services - Bzns Book</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('web.main.meta')
</head>
<body>
    <main class="page-wrapper">
        @include('web.main.navbar')
        <section class="container pt-5">
            <div class="row">
                @include('web.sections.profile.side')

                <!-- Services list and management section -->
                <div class="col-md-8 mb-lg-4 pt-md-5 mt-n3 mt-md-0">
                    <div class="ps-md-3 ps-lg-0 mt-md-2">
                        <div class="mb-4 d-flex align-items-center justify-content-between">
                            <h1 class="mb-0 h2 pt-xl-1">My Services</h1>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addServiceModal">
                                <i class="bx bx-plus fs-lg me-2"></i>Add Service
                            </button>
                        </div>

                        @if(session('success'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('success') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        @endif

                        @if(session('error'))
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                {{ session('error') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        @endif

                        <!-- Services grid -->
                        <div class="mt-5 mb-4 row row-cols-1 row-cols-md-2 g-4">
                            @forelse($services as $service)
                                <!-- Service item -->
                                <div class="mb-4 col-md-6">
                                    <div class="pt-5 border-0 shadow-sm card card-hover h-100 text-decoration-none px-sm-3 px-md-0 px-lg-3 pb-sm-3 pb-md-0 pb-lg-3">
                                        <div class="pt-3 card-body">
                                            <!-- Service icon with primary background -->
                                            <div class="top-0 p-3 d-inline-block bg-dark shadow-dark rounded-3 position-absolute translate-middle-y">
                                                <i class="m-1 text-white bx bx-briefcase d-block" style="font-size: 24px;"></i>
                                            </div>

                                            <div class="mb-3 d-flex justify-content-between align-items-center">
                                                <!-- Service title with arrow -->
                                                <h2 class="mb-0 h4 d-inline-flex align-items-center">
                                                    <a href="{{ route('client.services.show', $service->id) }}" class="text-decoration-none text-dark">
                                                        {{ $service->name }}
                                                        <i class="bx bx-right-arrow-circle text-dark fs-3 ms-2"></i>
                                                    </a>
                                                </h2>

                                                <!-- Actions dropdown -->
                                                <div class="dropdown">
                                                    <button class="text-muted btn btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="bx bx-dots-vertical-rounded fs-4"></i>
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <li>
                                                            <a href="{{ route('client.services.show', $service->id) }}" class="dropdown-item">
                                                                <i class="bx bx-show me-2"></i> View Details
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <button class="dropdown-item edit-service-btn"
                                                                data-id="{{ $service->id }}"
                                                                data-name="{{ $service->name }}"
                                                                data-description="{{ $service->details }}"
                                                                data-price="{{ $service->price }}"
                                                                data-years_experience="{{ $service->years_experience }}"
                                                                data-level="{{ $service->level ?? 3 }}"
                                                                data-skills="{{ json_encode($service->skills) }}"
                                                                data-bs-toggle="tooltip"
                                                                data-bs-placement="left"
                                                                title="Edit Service">
                                                                <i class="bx bx-edit me-2"></i> Edit
                                                            </button>
                                                        </li>
                                                        <li>
                                                            <form action="{{ route('client.services.delete', $service->id) }}" method="POST" class="d-inline">
                                                                @csrf
                                                                @method('DELETE')
                                                                <button type="submit" class="dropdown-item text-danger" onclick="return confirm('Are you sure you want to delete this service?')">
                                                                    <i class="bx bx-trash me-2"></i> Delete
                                                                </button>
                                                            </form>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <!-- Service description -->
                                            <div class="mb-3">
                                                @if($service->details)
                                                    <p class="mb-3 fs-sm text-body">{{ \Illuminate\Support\Str::limit($service->details, 120) }}</p>
                                                @else
                                                    <p class="mb-3 fs-sm text-muted">No description available</p>
                                                @endif

                                                <!-- Price -->
                                                @if($service->price)
                                                    <div class="mb-3 d-flex align-items-center">
                                                        <span class="badge bg-faded-primary text-primary me-2"><i class="bx bx-money me-1"></i> {{ number_format($service->price, 2) }} EGP</span>

                                                        <!-- Level as stars -->
                                                        @if($service->level)
                                                            <div class="d-flex align-items-center ms-auto">
                                                                @for($i = 1; $i <= 5; $i++)
                                                                    @if($i <= $service->level)
                                                                        <i class="bx bxs-star text-dark"></i>
                                                                    @else
                                                                        <i class="bx bx-star text-muted"></i>
                                                                    @endif
                                                                @endfor
                                                            </div>
                                                        @endif
                                                    </div>
                                                @endif

                                                <!-- Skills tags -->
                                                @if(is_array($service->skills) && count($service->skills) > 0)
                                                    <div class="flex-wrap gap-1 d-flex">
                                                        @foreach(array_slice($service->skills, 0, 3) as $skill)
                                                            <span class="badge bg-faded-primary text-primary">{{ $skill }}</span>
                                                        @endforeach
                                                        @if(count($service->skills) > 3)
                                                            <span class="badge bg-light text-dark">+{{ count($service->skills) - 3 }}</span>
                                                        @endif
                                                    </div>
                                                @endif
                                            </div>

                                            <!-- Card footer with metadata -->
                                            <div class="pt-3 d-flex text-muted border-top">
                                                <div class="d-flex">
                                                    @if($service->years_experience)
                                                        <div class="d-flex align-items-center me-4">
                                                            <i class="bx bx-time fs-xl me-1"></i>
                                                            {{ $service->years_experience }} years exp.
                                                        </div>
                                                    @endif

                                                    @if($service->subcategories->count() > 0)
                                                        <div class="d-flex align-items-center">
                                                            <i class="bx bx-category fs-xl me-1"></i>
                                                            {{ $service->subcategories->count() }} categories
                                                        </div>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <div class="col-12">
                                    <div class="p-4 text-center rounded border">
                                        <i class="mb-2 display-6 bx bx-server text-muted"></i>
                                        <p class="mb-3">You haven't added any services yet.</p>
                                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addServiceModal">
                                            <i class="bx bx-plus me-2"></i>Add Your First Service
                                        </button>
                                    </div>
                                </div>
                            @endforelse
                        </div>

                        <!-- Pagination -->
                        {{ $services->links() }}
                    </div>
                </div>
            </div>
        </section>
        @include('web.main.footer')
    </main>
    @include('web.main.scripts')

    <!-- Add Service Modal -->
    <div class="modal fade" id="addServiceModal" tabindex="-1" aria-labelledby="addServiceModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="{{ route('client.services.store') }}" method="POST">
                    @csrf
                    <div class="modal-header">
                        <h5 class="modal-title" id="addServiceModalLabel">Add Service</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Basic Info Section -->
                        <h6 class="mb-3 fw-bold">Basic Information</h6>
                        <div class="mb-3">
                            <label for="name" class="form-label">Service Name</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name') }}" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Details</label>
                            <textarea class="form-control @error('description') is-invalid @enderror" id="description" name="description" rows="3">{{ old('description') }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="text-muted">This will be stored in the 'details' field</small>
                        </div>

                        <div class="mb-3 row">
                            <div class="col-md-6">
                                <label for="price" class="form-label">Price (EGP)</label>
                                <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="price" name="price" value="{{ old('price') }}">
                                @error('price')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="years_experience" class="form-label">Years of Experience</label>
                                <input type="number" class="form-control @error('years_experience') is-invalid @enderror" id="years_experience" name="years_experience" value="{{ old('years_experience') }}">
                                @error('years_experience')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="level" class="form-label">Skill Level (1-5 stars)</label>
                            <div class="d-flex align-items-center">
                                <input type="range" class="form-range me-2" min="1" max="5" id="level" name="level" value="{{ old('level', 3) }}">
                                <div class="star-rating-display" id="level-stars">
                                    <i class="bx bxs-star"></i>
                                    <i class="bx bxs-star"></i>
                                    <i class="bx bxs-star"></i>
                                    <i class="bx bx-star"></i>
                                    <i class="bx bx-star"></i>
                                </div>
                                <span class="ms-2" id="level-value">3</span>
                            </div>
                            <small class="text-muted">Drag the slider to set your expertise level for this service</small>
                        </div>

                        <div class="mb-3">
                            <label for="skills" class="form-label">Skills (press Enter after each skill)</label>
                            <div class="skills-input-container">
                                <input type="text" class="form-control skills-input" id="skills-input" placeholder="Add skills...">
                                <div class="mt-2 skills-tags" id="skills-tags"></div>
                                <input type="hidden" name="skills" id="skills-hidden">
                            </div>
                            <small class="text-muted">Enter skills related to this service (e.g. WordPress, JavaScript, Marketing)</small>
                        </div>

                        <!-- Subcategories Section -->
                        <h6 class="mb-3 fw-bold">Subcategories</h6>
                        <div class="mb-3">
                            <label class="form-label">Select Subcategories</label>
                            @if($subcategories->count() > 0)
                                <div class="row">
                                    @foreach($subcategories as $subcategory)
                                        <div class="mb-2 col-md-4">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="subcategories[]" value="{{ $subcategory->id }}" id="subcategory{{ $subcategory->id }}">
                                                <label class="form-check-label" for="subcategory{{ $subcategory->id }}">
                                                    {{ $subcategory->name }}
                                                </label>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="alert alert-info">
                                    <i class="bx bx-info-circle me-1"></i> No subcategories available. You can add services without subcategories.
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Service</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Service Modal -->
    <div class="modal fade" id="editServiceModal" tabindex="-1" aria-labelledby="editServiceModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form id="editServiceForm" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="modal-header">
                        <h5 class="modal-title" id="editServiceModalLabel">Edit Service</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Basic Info Section -->
                        <h6 class="mb-3 fw-bold">Basic Information</h6>
                        <div class="mb-3">
                            <label for="edit_name" class="form-label">Service Name</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" id="edit_name" name="name" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="edit_description" class="form-label">Details</label>
                            <textarea class="form-control @error('description') is-invalid @enderror" id="edit_description" name="description" rows="3"></textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="text-muted">This will be stored in the 'details' field</small>
                        </div>

                        <div class="mb-3 row">
                            <div class="col-md-6">
                                <label for="edit_price" class="form-label">Price (EGP)</label>
                                <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="edit_price" name="price">
                                @error('price')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="edit_years_experience" class="form-label">Years of Experience</label>
                                <input type="number" class="form-control @error('years_experience') is-invalid @enderror" id="edit_years_experience" name="years_experience">
                                @error('years_experience')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="edit_level" class="form-label">Skill Level (1-5 stars)</label>
                            <div class="d-flex align-items-center">
                                <input type="range" class="form-range me-2" min="1" max="5" id="edit_level" name="level" value="3">
                                <div class="star-rating-display" id="edit-level-stars">
                                    <i class="bx bxs-star"></i>
                                    <i class="bx bxs-star"></i>
                                    <i class="bx bxs-star"></i>
                                    <i class="bx bx-star"></i>
                                    <i class="bx bx-star"></i>
                                </div>
                                <span class="ms-2" id="edit-level-value">3</span>
                            </div>
                            <small class="text-muted">Drag the slider to set your expertise level for this service</small>
                        </div>

                        <div class="mb-3">
                            <label for="edit_skills" class="form-label">Skills (press Enter after each skill)</label>
                            <div class="skills-input-container">
                                <input type="text" class="form-control skills-input" id="edit-skills-input" placeholder="Add skills...">
                                <div class="mt-2 skills-tags" id="edit-skills-tags"></div>
                                <input type="hidden" name="skills" id="edit-skills-hidden">
                            </div>
                            <small class="text-muted">Enter skills related to this service (e.g. WordPress, JavaScript, Marketing)</small>
                        </div>

                        <!-- Subcategories Section -->
                        <h6 class="mb-3 fw-bold">Subcategories</h6>
                        <div class="mb-3">
                            <label class="form-label">Select Subcategories</label>
                            @if($subcategories->count() > 0)
                                <div class="row">
                                    @foreach($subcategories as $subcategory)
                                        <div class="mb-2 col-md-4">
                                            <div class="form-check">
                                                <input class="form-check-input edit-subcategory-checkbox" type="checkbox" name="subcategories[]" value="{{ $subcategory->id }}" id="edit_subcategory{{ $subcategory->id }}">
                                                <label class="form-check-label" for="edit_subcategory{{ $subcategory->id }}">
                                                    {{ $subcategory->name }}
                                                </label>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="alert alert-info">
                                    <i class="bx bx-info-circle me-1"></i> No subcategories available. You can update this service without subcategories.
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Service</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <style>
        .skills-input-container {
            position: relative;
        }

        .skills-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .skill-tag {
            display: inline-flex;
            align-items: center;
            background: #f0f9ff;
            border: 1px solid #a6d5fa;
            color: #0d6efd;
            border-radius: 20px;
            padding: 3px 10px;
            margin-right: 5px;
        }

        .remove-tag {
            display: inline-flex;
            margin-left: 5px;
            cursor: pointer;
            color: #dc3545;
        }
    </style>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Handle star rating display for Add form
        const levelSlider = document.getElementById('level');
        const levelStars = document.getElementById('level-stars').querySelectorAll('i');
        const levelValue = document.getElementById('level-value');

        if (levelSlider) {
            // Initialize stars based on default value
            updateStars(levelSlider.value, levelStars);

            levelSlider.addEventListener('input', function() {
                const value = this.value;
                levelValue.textContent = value;
                updateStars(value, levelStars);
            });
        }

        // Handle star rating display for Edit form
        const editLevelSlider = document.getElementById('edit_level');
        const editLevelStars = document.getElementById('edit-level-stars').querySelectorAll('i');
        const editLevelValue = document.getElementById('edit-level-value');

        if (editLevelSlider) {
            // Function will be called when edit modal opens with service level
            editLevelSlider.addEventListener('input', function() {
                const value = this.value;
                editLevelValue.textContent = value;
                updateStars(value, editLevelStars);
            });
        }

        // Helper function to update star display
        function updateStars(value, stars) {
            const numStars = parseInt(value);
            stars.forEach((star, index) => {
                if (index < numStars) {
                    star.classList.remove('bx-star');
                    star.classList.add('bxs-star');
                } else {
                    star.classList.remove('bxs-star');
                    star.classList.add('bx-star');
                }
            });
        }

        // Handle edit service button clicks
        // Skills tag input functionality for Add form
        const skillsInput = document.getElementById('skills-input');
        const skillsTags = document.getElementById('skills-tags');
        const skillsHidden = document.getElementById('skills-hidden');
        const skills = [];

        function updateSkillsHidden() {
            skillsHidden.value = JSON.stringify(skills);
        }

        function addSkill(skill) {
            if (skill && !skills.includes(skill)) {
                skills.push(skill);
                updateSkillsHidden();

                const tagElement = document.createElement('div');
                tagElement.className = 'skill-tag';
                tagElement.innerHTML = `
                    <span>${skill}</span>
                    <span class="remove-tag"><i class="bx bx-x"></i></span>
                `;

                tagElement.querySelector('.remove-tag').addEventListener('click', function() {
                    const index = skills.indexOf(skill);
                    if (index !== -1) {
                        skills.splice(index, 1);
                        updateSkillsHidden();
                        tagElement.remove();
                    }
                });

                skillsTags.appendChild(tagElement);
            }
        }

        if (skillsInput) {
            skillsInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    const skill = this.value.trim();
                    if (skill) {
                        addSkill(skill);
                        this.value = '';
                    }
                }
            });
        }

        // Skills tag input functionality for Edit form
        const editSkillsInput = document.getElementById('edit-skills-input');
        const editSkillsTags = document.getElementById('edit-skills-tags');
        const editSkillsHidden = document.getElementById('edit-skills-hidden');
        let editSkills = [];

        function updateEditSkillsHidden() {
            editSkillsHidden.value = JSON.stringify(editSkills);
        }

        function addEditSkill(skill) {
            if (skill && !editSkills.includes(skill)) {
                editSkills.push(skill);
                updateEditSkillsHidden();

                const tagElement = document.createElement('div');
                tagElement.className = 'skill-tag';
                tagElement.innerHTML = `
                    <span>${skill}</span>
                    <span class="remove-tag"><i class="bx bx-x"></i></span>
                `;

                tagElement.querySelector('.remove-tag').addEventListener('click', function() {
                    const index = editSkills.indexOf(skill);
                    if (index !== -1) {
                        editSkills.splice(index, 1);
                        updateEditSkillsHidden();
                        tagElement.remove();
                    }
                });

                editSkillsTags.appendChild(tagElement);
            }
        }

        if (editSkillsInput) {
            editSkillsInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    const skill = this.value.trim();
                    if (skill) {
                        addEditSkill(skill);
                        this.value = '';
                    }
                }
            });
        }

        // Edit Service button click handler
        document.querySelectorAll('.edit-service').forEach(button => {
            button.addEventListener('click', function() {
                const serviceId = this.getAttribute('data-id');
                const serviceName = this.getAttribute('data-name');
                const serviceDescription = this.getAttribute('data-description'); // This is actually details
                const servicePrice = this.getAttribute('data-price');
                const serviceYearsExperience = this.getAttribute('data-years_experience');
                const serviceLevel = this.getAttribute('data-level') || 3;
                const serviceSkills = this.getAttribute('data-skills');

                // Reset edit skills
                editSkills = [];
                editSkillsTags.innerHTML = '';

                // Set form action
                document.getElementById('editServiceForm').setAttribute('action', `/profile/services/${serviceId}`);

                // Set form values
                document.getElementById('edit_name').value = serviceName;
                document.getElementById('edit_description').value = serviceDescription;
                document.getElementById('edit_price').value = servicePrice;
                document.getElementById('edit_years_experience').value = serviceYearsExperience;

                // Set level value and update star display
                const levelInput = document.getElementById('edit_level');
                levelInput.value = serviceLevel;
                editLevelValue.textContent = serviceLevel;
                updateStars(serviceLevel, editLevelStars);

                // Parse and set skills
                if (serviceSkills) {
                    try {
                        const skillsArray = JSON.parse(serviceSkills);
                        if (Array.isArray(skillsArray)) {
                            skillsArray.forEach(skill => addEditSkill(skill));
                        }
                    } catch (e) {
                        console.error('Error parsing skills:', e);
                    }
                }

                // Clear all subcategory checkboxes
                document.querySelectorAll('.edit-subcategory-checkbox').forEach(checkbox => {
                    checkbox.checked = false;
                });

                // Fetch service subcategories and check appropriate boxes
                fetch(`/profile/services/${serviceId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.subcategories && data.subcategories.length) {
                            data.subcategories.forEach(subcategoryId => {
                                const checkbox = document.getElementById(`edit_subcategory${subcategoryId}`);
                                if (checkbox) {
                                    checkbox.checked = true;
                                }
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching service subcategories:', error);
                    });
            });
        });

        // Handle delete confirmation
        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                if (!confirm('Are you sure you want to delete this service? This action cannot be undone.')) {
                    e.preventDefault();
                }
            });
        });
    });
</script>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        // Profile picture upload functionality
        const changePictureBtn = document.getElementById('change-picture-btn');
        const profilePictureInput = document.getElementById('profile-picture-input');
        const profilePictureForm = document.getElementById('profile-picture-form');

        if (changePictureBtn && profilePictureInput && profilePictureForm) {
          changePictureBtn.addEventListener('click', function() {
            profilePictureInput.click();
          });

          profilePictureInput.addEventListener('change', function() {
            if (profilePictureInput.files.length > 0) {
              profilePictureForm.submit();
            }
          });
        }
      });
    </script>
</body>
</html>
