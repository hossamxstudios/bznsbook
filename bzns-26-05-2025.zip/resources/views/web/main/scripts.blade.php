


    <!-- Back to top button -->
    <a href="#top" class="btn-scroll-top" data-scroll>
        <span class="btn-scroll-top-tooltip text-muted fs-sm me-2">Top</span>
        <i class="btn-scroll-top-icon bx bx-chevron-up"></i>
      </a>


      <!-- Vendor Scripts -->
      <script src="{{ URL::asset('assets/vendor/jarallax/dist/jarallax.min.js') }}"></script>
      <script src="{{ URL::asset('assets/vendor/rellax/rellax.min.js') }}"></script>
      <script src="{{ URL::asset('assets/vendor/parallax-js/dist/parallax.min.js') }}"></script>
      <script src="{{ URL::asset('assets/vendor/@lottiefiles/lottie-player/dist/lottie-player.js') }}"></script>
      <script src="{{ URL::asset('assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
      <script src="{{ URL::asset('assets/vendor/lightgallery/lightgallery.min.js') }}"></script>
      <script src="{{ URL::asset('assets/vendor/lightgallery/plugins/video/lg-video.min.js') }}"></script>
      <script src="{{ URL::asset('assets/vendor/imagesloaded/imagesloaded.pkgd.min.js') }}"></script>
      <script src="{{ URL::asset('assets/vendor/shufflejs/dist/shuffle.min.js') }}"></script>

      <!-- Main Theme Script -->
      <script src="{{ URL::asset('assets/js/theme.min.js') }}"></script>