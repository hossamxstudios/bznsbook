<!doctype html>
@include('web.main.html')
<head>
    <meta charset="utf-8" />
    <title>International Shipping Guide | Bzns</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('web.main.meta')
    <style>
        /* Custom styles for the guide */
        .guide-header {
            background: linear-gradient(135deg, #3e3e3e 0%, #1a1a1a 100%);
            padding: 60px 0;
            margin-bottom: 0;
            position: relative;
        }
        .guide-title {
            font-weight: 700;
            letter-spacing: -0.5px;
            margin-bottom: 1rem;
        }
        .guide-subtitle {
            font-weight: 300;
            opacity: 0.9;
            margin-bottom: 1.5rem;
        }
        .guide-content {
            padding: 50px 0;
            background: #fff;
            position: relative;
        }
        .guide-content .container {
            position: relative;
        }
        .content-block {
            margin-bottom: 2rem;
            line-height: 1.7;
        }
        .content-visible {
            border-bottom: 1px solid #eee;
            padding-bottom: 2rem;
            margin-bottom: 2rem;
        }
        .content-blurred {
            position: relative;
            filter: blur(4px);
            user-select: none;
            pointer-events: none;
            opacity: 0.7;
        }
        .content-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.8) 70%, rgba(255,255,255,1) 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 10;
            padding-top: 100px;
        }
        .subscribe-card {
            background-color: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 500px;
            width: 90%;
            transform: translateY(-133px);
        }
        .subscribe-btn {
            background: #3e3e3e;
            color: white;
            font-weight: 600;
            border-radius: 50px;
            padding: 12px 35px;
            font-size: 16px;
            transition: all 0.3s ease;
            border: 2px solid #3e3e3e;
            display: inline-block;
            margin-top: 15px;
        }
        .subscribe-btn:hover {
            background: #555;
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        .section-title {
            font-weight: 700;
            margin-bottom: 1rem;
            color: #333;
            position: relative;
            display: inline-block;
        }
        .section-title:after {
            content: '';
            display: block;
            width: 70%;
            height: 3px;
            background: #3e3e3e;
            margin-top: 5px;
        }
        .list-styled {
            padding-left: 20px;
        }
        .list-styled li {
            margin-bottom: 0.75rem;
            position: relative;
            padding-left: 10px;
        }
        .list-styled li:before {
            content: '\2022';
            color: #3e3e3e;
            font-weight: bold;
            display: inline-block;
            width: 1em;
            margin-left: -1em;
        }
        .featured-badge {
            display: inline-block;
            background-color: #f8f9fa;
            padding: 5px 15px;
            border-radius: 50px;
            font-weight: 500;
            font-size: 12px;
            color: #3e3e3e;
            border: 1px solid #eee;
            margin-bottom: 1rem;
        }
        .highlight-box {
            background-color: #f8f9fa;
            border-left: 4px solid #3e3e3e;
            padding: 20px;
            margin: 1.5rem 0;
            border-radius: 0 5px 5px 0;
        }
        .highlight-box p:last-child {
            margin-bottom: 0;
        }
    </style>
</head>
<body>
    <main class="page-wrapper">
        @include('web.main.navbar')

        <!-- Guide Content Section -->
        <section class="guide-content">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <!-- Introduction - Visible Content -->
                        <div class="content-block content-visible">
                            <h2 class="section-title">International Shipping Guide</h2>
                            <p>
                                Navigating international shipping requires understanding complex regulations, documentation requirements, and logistics planning. This guide provides essential knowledge for businesses looking to expand their global reach through efficient shipping operations.
                            </p>
                        </div>

                        <!-- Strategy Section - Blurred Content -->
                        <div class="content-block content-blurred">
                            <h2 class="section-title">Global Shipping Best Practices</h2>
                            <p>
                                Successful international shipping strategies involve careful consideration of shipping methods, customs procedures, carrier selection, and compliance with international trade regulations.
                            </p>

                            <h3>1. Documentation & Customs Requirements</h3>
                            <p>
                                Proper documentation is critical for smooth international shipments:
                            </p>

                            <div class="highlight-box">
                                <p><strong>Expert Tip:</strong> Implementing a standardized documentation system can reduce customs delays by up to 45% and decrease compliance issues by over 60%.</p>
                            </div>

                            <h3>2. Freight Forwarding & Logistics Partners</h3>
                            <p>
                                Selecting the right shipping partners is essential for optimizing your global supply chain:
                            </p>

                            <h3>3. Cost Management Strategies</h3>
                            <p>
                                Effective cost control measures for international shipping include:
                            </p>
                        </div>

                        <!-- Subscription Overlay -->
                        <div class="content-overlay">
                            <div class="subscribe-card">
                                <h3>Access the Complete Shipping Guide</h3>
                                <p class="mb-4">Unlock our comprehensive international shipping resources, cost-saving strategies, and compliance frameworks.</p>
                                <a href="#" class="subscribe-btn">Subscribe Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        @include('web.main.footer')
    </main>
    @include('web.main.scripts')
</body>
</html>
