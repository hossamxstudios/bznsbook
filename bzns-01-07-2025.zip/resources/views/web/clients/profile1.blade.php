<!doctype html>
@include('web.main.html')

<head>
    <meta charset="utf-8" />
    <title> Bzns Book | {{ $client->name }} Profile </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('web.main.meta')

</head>

<body>
    <main class="page-wrapper">
        @include('web.main.navbar')
        <section class="pt-lg-4 mt-lg-3">
            <div class="overflow-hidden position-relative">
                <!-- Image -->
                <div class="top-0 container-fluid position-relative position-lg-absolute start-0 h-100">
                    <div class="row h-100 me-n4 me-n2">
                        <div class="col-lg-7 position-relative">
                            <div class="d-none d-sm-block d-lg-none" style="height: 400px;"></div>
                            <div class="d-sm-none" style="height: 300px;"></div>
                            <div class="overflow-hidden top-0 position-absolute start-0 w-100 h-100 rounded-3 rounded-start-0" data-jarallax data-speed="0.3">
                                @if ($client->hasMedia('cover'))
                                    @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                        <div class="jarallax-img" style="background-image: url({{ $client->getFirstMediaUrl('cover') }});background-size: cover; background-repeat: no-repeat;"></div>
                                    @else
                                        <div class="jarallax-img position-relative" style="background-image: url({{ $client->getFirstMediaUrl('cover') }});background-size: cover; background-repeat: no-repeat; filter: blur(10px);"></div>
                                        <div class="position-absolute top-50 start-50 translate-middle" style="z-index: 2;">
                                            <i class="bx bx-lock-alt fs-1 text-light"></i>
                                        </div>
                                    @endif
                                @else
                                    <div class="jarallax-img" style="background-image: url({{ asset('assets/img/landing/financial/hero-img.jpg') }}); background-size: contain; background-repeat: no-repeat;"></div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container px-0 position-relative zindex-5 pt-lg-5 px-lg-3">
                    <div class="row pt-lg-5 mx-n4 mx-lg-n3">
                        <div class="pb-5 col-xl-8 col-lg-7 offset-lg-5 offset-xl-6">
                            <!-- Card -->
                            <div class="overflow-hidden px-2 py-4 card bg-dark border-light p-sm-4">
                                <span class="top-0 position-absolute start-0 w-100 h-50"
                                    style="background-color: rgba(255,255,255,.05);"></span>
                                <div class="card-body position-relative zindex-5">
                                    <div class="mb-4 d-flex align-items-center">
                                        <div class="square-image-container rounded-3 position-relative"
                                            style="width: 350px; height: 250px; background-color: #fff; overflow: hidden;">
                                            @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                <img src="{{ $client->getFirstMediaUrl('profile') ?? asset('assets/img/logo-square.png') }}" alt="Company Logo" class="w-100 h-100" style="object-fit: cover;" onerror="this.src='https://placehold.co/150x150/4733ff/ffffff?text=LOGO'">
                                            @else
                                                <img src="{{ $client->getFirstMediaUrl('profile') ?? asset('assets/img/logo-square.png') }}" alt="Blurred Company Logo" class="w-100 h-100" style="object-fit: cover; filter: blur(8px);" onerror="this.src='https://placehold.co/150x150/4733ff/ffffff?text=LOGO'">
                                                <div class="position-absolute top-50 start-50 translate-middle" style="z-index: 2;">
                                                    <i class="bx bx-lock-alt fs-1 text-light"></i>
                                                </div>
                                            @endif
                                        </div>
                                        <div class="ms-4">
                                            <span class="mb-1 d-block text-light text-uppercase small">{{ $client->type ?? 'Business' }}</span>
                                            <h2 class="mb-0 text-light fw-bold">
                                                @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                    {{ $client->name }}
                                                @else
                                                    {{ Illuminate\Support\Str::mask($client->name, '*', 3, strlen($client->name) - 4) }}
                                                @endif
                                            </h2>
                                            <div class="mb-2 text-white d-flex align-items-center">
                                                <i class="bx bxs-time me-2"></i>
                                                <div class="d-flex align-items-center" >
                                                    <i class="bx bxs-circle me-1 {{ $client->last_seen->diffInMinutes() < 5 ? 'text-success' : 'text-white' }}" style="font-size: 0.5rem;"></i>
                                                    @if ($client->last_seen->diffInMinutes() < 5)
                                                        <span class="text-success">Online now</span>
                                                    @elseif ($client->last_seen->isToday())
                                                        <span>Last seen today at {{ $client->last_seen->format('h:i A') }}</span>
                                                    @elseif ($client->last_seen->isYesterday())
                                                        <span>Last seen yesterday at {{ $client->last_seen->format('h:i A') }}</span>
                                                    @elseif ($client->last_seen->diffInDays() < 7)
                                                        <span>Last seen {{ $client->last_seen->diffForHumans() }}</span>
                                                    @else
                                                        <span>Last seen on {{ $client->last_seen->format('M d, Y') }}</span>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="mb-4 opacity-70 fs-lg text-light">
                                        {{ Illuminate\Support\Str::limit($client->bio, 150) ?? 'Helping businesses reach their full potential with our expertise and tailored solutions.' }}
                                    </p>

                                    <!-- Client Info & Social Links -->
                                    <div class="mb-2 row text-light">
                                        <div class="mb-3 col-sm-6">
                                            <!-- Last Seen (Activity Status) -->
                                            {{-- @if ($client->last_seen && (Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())) --}}

                                            {{-- @endif --}}

                                            <!-- Website -->
                                            @if ($client->website)
                                                <div class="mb-2 d-flex align-items-center">
                                                    <i class="bx bx-globe me-2"></i>
                                                    @if (Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                        <a href="{{ $client->website }}" class="text-light text-decoration-none" target="_blank">{{ Illuminate\Support\Str::limit($client->website, 25) }}</a>
                                                    @else
                                                        <div class="d-flex align-items-center">
                                                            <span class="text-light text-decoration-none me-2">{{ Illuminate\Support\Str::mask($client->website, '*', 5) }}</span>
                                                            <i class="bx bx-lock-alt text-light" data-bs-toggle="tooltip" title="Subscribe to view"></i>
                                                        </div>
                                                    @endif
                                                </div>
                                            @endif

                                            <!-- Social Media -->
                                            <div class="mb-2 d-flex align-items-center">
                                                @if ($client->facebook)
                                                    @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                        <a href="{{ $client->facebook }}" class="text-light me-3" target="_blank"><i class="bx bxl-facebook-square fs-4"></i></a>
                                                    @else
                                                        <span class="text-light me-3 position-relative" style="cursor: not-allowed;">
                                                            <i class="opacity-50 bx bxl-facebook-square fs-4"></i>
                                                            <span class="top-0 position-absolute start-100 translate-middle badge rounded-pill bg-dark" style="font-size: 8px;"><i class="bx bx-lock-alt"></i></span>
                                                        </span>
                                                    @endif
                                                @endif

                                                @if ($client->linkedin)
                                                    @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                        <a href="{{ $client->linkedin }}" class="text-light me-3" target="_blank"><i class="bx bxl-linkedin-square fs-4"></i></a>
                                                    @else
                                                        <span class="text-light me-3 position-relative" style="cursor: not-allowed;">
                                                            <i class="opacity-50 bx bxl-linkedin-square fs-4"></i>
                                                            <span class="top-0 position-absolute start-100 translate-middle badge rounded-pill bg-dark" style="font-size: 8px;"><i class="bx bx-lock-alt"></i></span>
                                                        </span>
                                                    @endif
                                                @endif

                                                @if ($client->instagram)
                                                    @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                        <a href="{{ $client->instagram }}" class="text-light me-3" target="_blank"><i class="bx bxl-instagram fs-4"></i></a>
                                                    @else
                                                        <span class="text-light me-3 position-relative" style="cursor: not-allowed;">
                                                            <i class="opacity-50 bx bxl-instagram fs-4"></i>
                                                            <span class="top-0 position-absolute start-100 translate-middle badge rounded-pill bg-dark" style="font-size: 8px;"><i class="bx bx-lock-alt"></i></span>
                                                        </span>
                                                    @endif
                                                @endif

                                                @if ($client->youtube)
                                                    @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                        <a href="{{ $client->youtube }}" class="text-light" target="_blank"><i class="bx bxl-youtube fs-4"></i></a>
                                                    @else
                                                        <span class="text-light position-relative" style="cursor: not-allowed;">
                                                            <i class="opacity-50 bx bxl-youtube fs-4"></i>
                                                            <span class="top-0 position-absolute start-100 translate-middle badge rounded-pill bg-dark" style="font-size: 8px;"><i class="bx bx-lock-alt"></i></span>
                                                        </span>
                                                    @endif
                                                @endif
                                            </div>
                                        </div>

                                        <div class="mb-3 col-sm-6">
                                            <!-- Company Size -->
                                            @if ($client->company_size)
                                                <div class="mb-2 d-flex align-items-center">
                                                    <i class="bx bx-group me-2"></i>
                                                    <span>{{ $client->company_size }}
                                                        {{ $client->is_company ? 'employees' : 'team members' }}</span>
                                                </div>
                                            @endif

                                            <!-- Founding Year -->
                                            @if ($client->founding_year)
                                                <div class="mb-2 d-flex align-items-center">
                                                    <i class="bx bx-calendar me-2"></i>
                                                    <span>Est. {{ $client->founding_year }}</span>
                                                </div>
                                            @endif

                                            <!-- Company Type -->
                                            <div class="d-flex align-items-center">
                                                <i class="bx bx-building me-2"></i>
                                                <span>{{ $client->is_company ? 'Company' : 'Individual' }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Content Sections -->
        <!-- About Section -->
        <section id="about" class="py-5 border-bottom">
            <div class="container">
                <div class="mb-4 d-flex align-items-center">
                    <i class="bx bx-info-circle fs-2 text-primary me-3"></i>
                    <h2 class="mb-0 fw-bold">About {{ $client->name }}</h2>
                </div>
                <div class="row">
                    <div class="col-lg-8">
                        <div class="mb-5">
                            <p class="mb-4">{{ $client->bio ?? 'No description available yet.' }}</p>
                            <!-- Company Metrics -->
                            <div class="mb-5 row g-4">
                                <!-- Team Size -->
                                <div class="col-sm-4">
                                    <div class="p-4 text-center rounded border">
                                        <div class="p-3 mb-3 d-inline-block bg-light rounded-circle">
                                            <i class="bx bx-group fs-3 text-primary"></i>
                                        </div>
                                        <h4 class="fs-5 fw-bold">{{ $client->company_size ?? '0' }}</h4>
                                        <p class="mb-0 text-muted">Team Members</p>
                                    </div>
                                </div>

                                <!-- Founding Year -->
                                <div class="col-sm-4">
                                    <div class="p-4 text-center rounded border">
                                        <div class="p-3 mb-3 d-inline-block bg-light rounded-circle">
                                            <i class="bx bx-calendar fs-3 text-primary"></i>
                                        </div>
                                        <h4 class="fs-5 fw-bold">{{ $client->founding_year ?? 'N/A' }}</h4>
                                        <p class="mb-0 text-muted">Established</p>
                                    </div>
                                </div>

                                <!-- Experience -->
                                <div class="col-sm-4">
                                    <div class="p-4 text-center rounded border">
                                        <div class="p-3 mb-3 d-inline-block bg-light rounded-circle">
                                            <i class="bx bx-time fs-3 text-primary"></i>
                                        </div>
                                        @php
                                            $yearsExperience = $client->founding_year
                                                ? date('Y') - $client->founding_year
                                                : 'N/A';
                                        @endphp
                                        <h4 class="fs-5 fw-bold">
                                            {{ is_numeric($yearsExperience) ? $yearsExperience : 'N/A' }}</h4>
                                        <p class="mb-0 text-muted">Years Experience</p>
                                    </div>
                                </div>
                            </div>
                            <!-- Languages -->
                            <div class="mb-5">
                                <h4 class="mb-3 fw-bold">Languages</h4>
                                <div class="flex-wrap d-flex">
                                    @if (isset($client->languages) && is_array(json_decode($client->languages)))
                                        @foreach (json_decode($client->languages) as $language)
                                            <span
                                                class="px-3 py-2 mb-2 badge bg-light me-2">{{ $language }}</span>
                                        @endforeach
                                    @else
                                        <span class="px-3 py-2 mb-2 badge bg-light me-2">English</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Contact Sidebar -->
                    <div class="col-lg-4">
                        <div class="border-0 shadow-sm card">
                            <div class="card-body">
                                <h4 class="mb-4 fw-bold">Contact Information</h4>
                                <ul class="mb-4 list-unstyled">
                                    @if ($client->email)
                                        <li class="mb-3 d-flex">
                                            <i class="mt-1 bx bx-envelope text-primary me-2"></i>
                                            <div>
                                                <p class="mb-0 fw-medium">Email</p>
                                                @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                    <a href="mailto:{{ $client->email }}" class="text-muted text-decoration-none">{{ $client->email }}</a>
                                                @else
                                                    <div class="position-relative">
                                                        <span class="text-muted">{{ Illuminate\Support\Str::mask($client->email, '*', 3, 5) }}</span>
                                                        <i class="ms-2 bx bx-lock-alt" data-bs-toggle="tooltip" title="Subscribe to view"></i>
                                                    </div>
                                                @endif
                                            </div>
                                        </li>
                                    @endif

                                    @if ($client->phone)
                                        <li class="mb-3 d-flex">
                                            <i class="mt-1 bx bx-phone text-primary me-2"></i>
                                            <div>
                                                <p class="mb-0 fw-medium">Phone</p>
                                                @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                    <a href="tel:{{ $client->phone }}" class="text-muted text-decoration-none">{{ $client->phone }}</a>
                                                @else
                                                    <div class="position-relative">
                                                        <span class="text-muted" >{{ Illuminate\Support\Str::mask($client->phone, '*', 4, 4) }}</span>
                                                        <i class="ms-2 bx bx-lock-alt" data-bs-toggle="tooltip" title="Subscribe to view"></i>
                                                    </div>
                                                @endif
                                            </div>
                                        </li>
                                    @endif

                                    @if ($client->address)
                                        <li class="mb-3 d-flex">
                                            <i class="mt-1 bx bx-map text-primary me-2"></i>
                                            <div>
                                                <p class="mb-0 fw-medium">Address</p>
                                                @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                    <p class="mb-0 text-muted">{{ $client->address }}</p>
                                                @else
                                                    <div class="position-relative">
                                                        <span class="text-muted">{{ Illuminate\Support\Str::mask($client->address, '*', 5) }}</span>
                                                        <i class="ms-2 bx bx-lock-alt" data-bs-toggle="tooltip" title="Subscribe to view"></i>
                                                    </div>
                                                @endif
                                            </div>
                                        </li>
                                    @endif

                                    @if ($client->website)
                                        <li class="d-flex">
                                            <i class="mt-1 bx bx-globe text-primary me-2"></i>
                                            <div>
                                                <p class="mb-0 fw-medium">Website</p>
                                                @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                    <a href="{{ $client->website }}" target="_blank" class="text-muted text-decoration-none">{{ $client->website }}</a>
                                                @else
                                                    <div class="position-relative">
                                                        <span class="text-muted">{{ Illuminate\Support\Str::mask($client->website, '*', 7) }}</span>
                                                        <i class="ms-2 bx bx-lock-alt" data-bs-toggle="tooltip" title="Subscribe to view"></i>
                                                    </div>
                                                @endif
                                            </div>
                                        </li>
                                    @endif
                                </ul>

                                <!-- Social Media Links -->
                                <div class="d-flex">
                                    @if ($client->facebook)
                                        <a href="{{ $client->facebook }}"
                                            class="btn btn-sm btn-icon btn-secondary me-2" target="_blank">
                                            <i class="bx bxl-facebook"></i>
                                        </a>
                                    @endif

                                    @if ($client->linkedin)
                                        <a href="{{ $client->linkedin }}"
                                            class="btn btn-sm btn-icon btn-secondary me-2" target="_blank">
                                            <i class="bx bxl-linkedin"></i>
                                        </a>
                                    @endif

                                    @if ($client->instagram)
                                        <a href="{{ $client->instagram }}"
                                            class="btn btn-sm btn-icon btn-secondary me-2" target="_blank">
                                            <i class="bx bxl-instagram"></i>
                                        </a>
                                    @endif

                                    @if ($client->youtube)
                                        <a href="{{ $client->youtube }}" class="btn btn-sm btn-icon btn-secondary"
                                            target="_blank">
                                            <i class="bx bxl-youtube"></i>
                                        </a>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Services Section -->
            <!-- Services Section -->
            <section id="services" class="py-5 border-bottom bg-light">
                <div class="container">
                    <div class="mb-4 d-flex align-items-center">
                        <i class="bx bx-server fs-2 text-primary me-3"></i>
                        <h2 class="mb-0 fw-bold">Services</h2>
                    </div>

                    <p class="mb-4">{{ count($client->services) }} services offered by {{ $client->name }}</p>

                    <div class="mb-4 rounded shadow bg-light">
                        <!-- Services Table Header -->
                        <div class="py-3 mx-0 row border-bottom bg-light fw-medium">
                            <div class="col-md-4 ps-4">
                                <strong>Service name</strong>
                            </div>
                            <div class="col-md-3">
                                <div class="d-flex align-items-center">
                                    <strong>Experience level</strong>
                                    <i class="bx bx-info-circle text-muted ms-2" data-bs-toggle="tooltip"
                                        title="Experience level based on completed projects"></i>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <strong>Related reviews</strong>
                            </div>
                            <div class="col-md-3">
                                <strong>Starting from</strong>
                            </div>
                        </div>

                        <style>
                            .service-row:hover {
                                background-color: rgba(0, 0, 0, 0.01);
                            }

                            .experience-dots i {
                                font-size: 0.5rem;
                            }

                            .service-icon {
                                width: 45px;
                                height: 45px;
                                display: flex;
                                align-items: center;
                                justify-content: center;
                                border-radius: 8px;
                                flex-shrink: 0;
                            }

                            .service-details {
                                transition: all 0.3s ease;
                            }

                            .price-badge {
                                white-space: nowrap;
                                font-weight: 600;
                            }

                            .detail-toggle {
                                transition: transform 0.2s ease;
                            }

                            .detail-toggle[aria-expanded="true"] {
                                transform: rotate(180deg);
                            }
                        </style>

                        @if (count($client->services) > 0)
                            @foreach ($client->services as $service)
                                <!-- Service Item -->
                                <div class="py-3 mx-0 row border-bottom align-items-center service-row">
                                    <!-- Service Name -->
                                    <div class="col-md-4 ps-4">
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="service-icon bg-light-{{ $service->category ? strtolower(str_replace(' ', '-', $service->category->name)) : 'primary' }} me-3">
                                                <i
                                                    class="bx bx-{{ $service->category ? strtolower(str_replace(' ', '-', $service->category->name)) : 'server' }} fs-4 text-{{ $service->category ? strtolower(str_replace(' ', '-', $service->category->name)) : 'primary' }}"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-bold">{{ $service->title ?? $service->name }}</h6>
                                                @if (isset($service->subcategories) && $service->subcategories->isNotEmpty())
                                                    <small
                                                        class="text-muted">{{ $service->subcategories->first()->name }}</small>
                                                @elseif($service->category)
                                                    <small class="text-muted">{{ $service->category->name }}</small>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Experience Level -->
                                    <div class="col-md-3">
                                        <div class="mb-1 experience-dots">
                                            @for ($i = 1; $i <= 10; $i++)
                                                @if ($i <= $service->rating * 2)
                                                    <i class="bx bxs-circle me-1"></i>
                                                @else
                                                    <i class="bx bxs-circle me-1" style="color: #e0e0e0;"></i>
                                                @endif
                                            @endfor
                                        </div>
                                        <small
                                            class="text-muted d-block">{{ $service->projects_count ?? rand(3, 16) }}
                                            works</small>
                                    </div>

                                    <!-- Related Reviews -->
                                    <div class="col-md-2">
                                        <div class="star-rating">
                                            @for ($i = 1; $i <= 5; $i++)
                                                <i class="bx bxs-star"></i>
                                            @endfor
                                            <span class="ms-1">({{ $service->reviews_count ?? rand(0, 6) }})</span>
                                        </div>
                                    </div>

                                    <!-- Starting Price -->
                                    <div class="col-md-3">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <span
                                                class="price-badge text-primary">{{ number_format($service->price) }}
                                                EGP<span class="text-muted">/project</span></span>
                                            <button class="btn btn-sm btn-outline-secondary ms-2 detail-toggle"
                                                type="button" data-bs-toggle="collapse"
                                                data-bs-target="#serviceDetails{{ $service->id }}"
                                                aria-expanded="false">
                                                <i class="bx bx-chevron-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Collapsed Service Details -->
                                <div class="collapse service-details" id="serviceDetails{{ $service->id }}">
                                    <div class="p-4 bg-light">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <h6 class="mb-3 fw-bold">Description</h6>
                                                <p class="mb-4 text-muted">
                                                    {{ $service->description ?? 'This service helps businesses improve their performance and reach their goals through professional consultation and implementation.' }}
                                                </p>

                                                @if (isset($service->skills) && count($service->skills) > 0)
                                                    <div class="mb-4">
                                                        <h6 class="mb-2 fw-bold">Skills & Expertise</h6>
                                                        <div class="flex-wrap d-flex">
                                                            @foreach ($service->skills as $skill)
                                                                <span
                                                                    class="px-3 py-2 mb-2 badge rounded-pill bg-light me-2">{{ $skill }}</span>
                                                            @endforeach
                                                        </div>
                                                    </div>
                                                @endif

                                                <div class="mb-3">
                                                    <h6 class="mb-2 fw-bold">Skill Level</h6>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-3">
                                                            @for ($i = 1; $i <= 5; $i++)
                                                                @if ($i <= $service->rating)
                                                                    <i class="bx bxs-star"></i>
                                                                @else
                                                                    <i class="bx bx-star"></i>
                                                                @endif
                                                            @endfor
                                                        </div>
                                                        <span class="small">{{ $service->rating }}/5 -
                                                            {{ $service->projects_count ?? rand(3, 16) }} successful
                                                            projects</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="p-4 rounded shadow-sm bg-light">
                                                    <h6 class="mb-3 fw-bold">Service Details</h6>
                                                    <div
                                                        class="pb-3 mb-3 border-bottom d-flex justify-content-between">
                                                        <span class="text-muted">Delivery time:</span>
                                                        <strong>{{ $service->delivery_time }} days</strong>
                                                    </div>
                                                    <div
                                                        class="pb-3 mb-4 border-bottom d-flex justify-content-between">
                                                        <span class="text-muted">Price:</span>
                                                        <strong
                                                            class="text-primary">{{ number_format($service->price) }}
                                                            EGP</strong>
                                                    </div>
                                                    <a href="#contact" class="py-2 btn btn-primary w-100">Contact for
                                                        quote</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @else
                            <div class="py-5 text-center">
                                <div class="mb-3">
                                    <i class="opacity-50 bx bx-server fs-1 text-secondary"></i>
                                </div>
                                <h5>No services available yet</h5>
                                <p class="mb-4 text-muted">This client hasn't added any services to their profile.</p>
                                <a href="#contact" class="btn btn-outline-primary">Contact for custom requests</a>
                            </div>
                        @endif
                    </div>
                </div>

                <!-- Services JavaScript -->
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Initialize tooltips
                        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
                        var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                            return new bootstrap.Tooltip(tooltipTriggerEl)
                        })

                        // Add hover effects to service rows
                        var serviceRows = document.querySelectorAll('.service-row')
                        serviceRows.forEach(function(row) {
                            row.addEventListener('mouseenter', function() {
                                this.style.transition = 'background-color 0.2s ease'
                            })
                        })
                    })
                </script>
            </section>

            <!-- Portfolio Section -->
            <section id="portfolio" class="py-5 bg-light border-bottom">
                <div class="container">
                    <div class="mb-4 d-flex align-items-center">
                        <i class="bx bx-images fs-2 text-primary me-3"></i>
                        <h2 class="mb-0 fw-bold">Our Portfolio</h2>
                    </div>
                    <p class="mb-4">{{ count($client->portfolios) }} projects in {{ $client->name }}'s portfolio
                    </p>
                    <div class="mb-4 row row-cols-1 row-cols-md-2 g-4">
                        @forelse($client->portfolios as $portfolio)
                            <!-- Portfolio item -->
                            <div class="mb-4 col pb-lg-2">
                                <article class="border-0 shadow-sm card h-100 portfolio-card">
                                    <div class="position-relative">
                                        <!-- Portfolio image -->
                                        @if ($portfolio->getFirstMedia('portfolio'))
                                            <img src="{{ $portfolio->getFirstMedia('portfolio')->getUrl() }}"
                                                class="card-img-top" alt="{{ $portfolio->name }}"
                                                style="height: 220px; object-fit: cover;">
                                        @else
                                            <div class="bg-light d-flex align-items-center justify-content-center"
                                                style="height: 220px;">
                                                <i class="bx bx-image-alt fs-1 text-muted"></i>
                                            </div>
                                        @endif

                                        @if ($portfolio->type)
                                            <span class="top-0 m-3 position-absolute start-0 badge bg-light">
                                                {{ $portfolio->type }}
                                            </span>
                                        @endif
                                    </div>

                                    <!-- Card body with title and client -->
                                    <div class="pb-3 card-body">
                                        <h3 class="mb-2 h5">
                                            {{ $portfolio->name }}
                                        </h3>
                                        @if ($portfolio->client_name)
                                            <p class="mb-2 fs-sm">Client: {{ $portfolio->client_name }}</p>
                                        @endif

                                        @if ($portfolio->details)
                                            <p class="mb-3 text-muted small">
                                                {{ \Illuminate\Support\Str::limit($portfolio->details, 120) }}</p>
                                        @endif

                                        @if (isset($portfolio->expertise) && is_array($portfolio->expertise))
                                            <div class="flex-wrap mb-2 d-flex">
                                                @foreach ($portfolio->expertise as $skill)
                                                    <span
                                                        class="mb-1 badge bg-light text-dark me-1">{{ $skill }}</span>
                                                @endforeach
                                            </div>
                                        @endif

                                        @if ($portfolio->project_url)
                                            <a href="{{ $portfolio->project_url }}" target="_blank"
                                                class="mt-2 btn btn-sm btn-primary">
                                                View Project <i class="bx bx-link-external ms-1"></i>
                                            </a>
                                        @endif
                                    </div>

                                    <!-- Card footer with metadata -->
                                    <div class="py-3 card-footer d-flex align-items-center fs-sm text-muted">
                                        <div class="d-flex align-items-center me-4">
                                            <i class="bx bx-calendar fs-xl me-1"></i>
                                            {{ $portfolio->date ? \Carbon\Carbon::parse($portfolio->date)->format('M Y') : 'No date' }}
                                        </div>
                                        @if ($portfolio->location)
                                            <div class="d-flex align-items-center">
                                                <i class="bx bx-map fs-xl me-1"></i>
                                                {{ $portfolio->location }}
                                            </div>
                                        @endif
                                    </div>
                                </article>
                            </div>
                        @empty
                            <div class="col-12">
                                <div class="py-5 text-center rounded bg-light">
                                    <div class="mb-3">
                                        <i class="opacity-50 bx bx-images fs-1 text-secondary"></i>
                                    </div>
                                    <h5>No portfolio items available yet</h5>
                                    <p class="mb-4 text-muted">This client hasn't added any projects to their
                                        portfolio.</p>
                                    <a href="#contact" class="btn btn-outline-primary">Request portfolio
                                        information</a>
                                </div>
                            </div>
                        @endforelse
                    </div>
                </div>
            </section>

            <!-- Contact Section -->
            <section id="contact" class="py-5">
                <div class="container">
                    <div class="mb-4 d-flex align-items-center">
                        <i class="bx bx-envelope fs-2 text-primary me-3"></i>
                        <h2 class="mb-0 fw-bold">Contact Us</h2>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <form action="#" method="post" class="mb-5">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="name" class="form-label">Your Name</label>
                                        <input type="text" class="form-control" id="name"
                                            placeholder="Enter your name" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="email" class="form-label">Your Email</label>
                                        <input type="email" class="form-control" id="email"
                                            placeholder="Enter your email" required>
                                    </div>
                                    <div class="col-12">
                                        <label for="subject" class="form-label">Subject</label>
                                        <input type="text" class="form-control" id="subject"
                                            placeholder="Enter subject">
                                    </div>
                                    <div class="col-12">
                                        <label for="message" class="form-label">Message</label>
                                        <textarea class="form-control" id="message" rows="5" placeholder="Enter your message" required></textarea>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="px-4 py-2 btn btn-primary">Send Message</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="col-lg-4">
                            <div class="border-0 shadow-sm card">
                                <div class="card-body">
                                    <h4 class="mb-4 fw-bold">Contact Information</h4>
                                    <ul class="mb-0 list-unstyled">
                                        {{-- @if ($client->last_seen && (Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())) --}}
                                            <li class="mb-3 d-flex">
                                                <i class="mt-1 bx bxs-time text-primary me-2"></i>
                                                <div>
                                                    <p class="mb-0 fw-medium">Activity Status</p>
                                                    <div class="d-flex align-items-center">
                                                        <i class="bx bxs-circle me-1 {{ $client->last_seen->diffInMinutes() < 5 ? 'text-success' : 'text-secondary' }}" style="font-size: 0.5rem;"></i>
                                                        @if ($client->last_seen->diffInMinutes() < 5)
                                                            <span class="text-success">Online now</span>
                                                        @elseif ($client->last_seen->isToday())
                                                            <span class="text-muted">Last seen today at {{ $client->last_seen->format('h:i A') }}</span>
                                                        @elseif ($client->last_seen->isYesterday())
                                                            <span class="text-muted">Last seen yesterday at {{ $client->last_seen->format('h:i A') }}</span>
                                                        @elseif ($client->last_seen->diffInDays() < 7)
                                                            <span class="text-muted">Last seen {{ $client->last_seen->diffForHumans() }}</span>
                                                        @else
                                                            <span class="text-muted">Last seen on {{ $client->last_seen->format('M d, Y') }}</span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </li>
                                        {{-- @endif --}}
                                        @if ($client->email)
                                            <li class="mb-3 d-flex">
                                                <i class="mt-1 bx bx-envelope text-primary me-2"></i>
                                                <div>
                                                    <p class="mb-0 fw-medium">Email</p>
                                                    @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                        <a href="mailto:{{ $client->email }}" class="text-muted text-decoration-none">{{ $client->email }}</a>
                                                    @else
                                                        <div class="position-relative">
                                                            <span class="text-muted" >{{ Illuminate\Support\Str::mask($client->email, '*', 3) }}</span>
                                                            <i class="ms-2 bx bx-lock-alt" data-bs-toggle="tooltip" title="Subscribe to view"></i>
                                                        </div>
                                                    @endif
                                                </div>
                                            </li>
                                        @endif

                                        @if ($client->phone)
                                            <li class="mb-3 d-flex">
                                                <i class="mt-1 bx bx-phone text-primary me-2"></i>
                                                <div>
                                                    <p class="mb-0 fw-medium">Phone</p>
                                                    @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                        <a href="tel:{{ $client->phone }}" class="text-muted text-decoration-none">{{ $client->phone }}</a>
                                                    @else
                                                        <div class="position-relative">
                                                            <span class="text-muted" >{{ Illuminate\Support\Str::mask($client->phone, '*', 4, 5) }}</span>
                                                            <i class="ms-2 bx bx-lock-alt" data-bs-toggle="tooltip" title="Subscribe to view"></i>
                                                        </div>
                                                    @endif
                                                </div>
                                            </li>
                                        @endif
                                        @if ($client->address)
                                        <li class="mb-3 d-flex">
                                            <i class="mt-1 bx bx-map text-primary me-2"></i>
                                            <div>
                                                <p class="mb-0 fw-medium">Address</p>
                                                @if(Auth::guard('client')->check() && Auth::guard('client')->user()->hasActiveSubscription())
                                                    <p class="mb-0 text-muted">{{ $client->address }}</p>
                                                @else
                                                    <div class="position-relative">
                                                        <span class="text-muted">{{ Illuminate\Support\Str::mask($client->address, '*', 5) }}</span>
                                                        <i class="ms-2 bx bx-lock-alt" data-bs-toggle="tooltip" title="Subscribe to view"></i>
                                                    </div>
                                                @endif
                                            </div>
                                        </li>
                                        @endif
                                        <li class="mb-3 d-flex">
                                            <i class="mt-1 bx bx-time text-primary me-2"></i>
                                            <div>
                                                <p class="mb-0 fw-medium">Business Hours</p>
                                                <p class="mb-0 text-muted">Mon - Fri: 9:00 AM - 5:00 PM</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            @include('web.main.footer')
    </main>
    @include('web.main.scripts')
</body>

</html>
