<div class="taskboard-body tab-content mt-5">
    @include('admin.sections.deals.kanban_view')
    @include('admin.sections.deals.table_view')
    @include('admin.sections.deals.activity')
</div>


