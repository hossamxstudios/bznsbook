<header class="hk-pg-header pg-header-wth-tab w-100 pt-1 d-none d-lg-block">
    <div>
        <div class="d-flex align-items-center">
            <div class="d-flex flex-wrap justify-content-between flex-1 py-2">
                <div class="menu-header">
                    <a class="navbar-brand" href="/">
                        <img class="brand-img" style="width: 152px" src="{{ URL::asset('crmlogo.png') }}" alt="brand">
                    </a>
                </div>
                <div>
                    <h1 class="pg-title fs-2 text-center pt-1"> Contact Form</h1>
                </div>
                <div class="pg-header-action-wrap position-relative">
                    <div class="d-md-flex d-none ms-auto align-items-center">
                        <img class="brand-img" style="width: 52px" src="{{ URL::asset('icon.png') }}" alt="brand">

                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
