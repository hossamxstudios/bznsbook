<header class="hk-pg-header pg-header-wth-tab">
    <div>
        <div class="d-flex align-items-center">
            <button class="btn btn-icon btn-rounded btn-flush-dark flush-soft-hover navbar-toggle me-2 d-xl-none"><span class="icon"><span class="feather-icon"><i data-feather="align-left"></i></span></span></button>
            <div class="avatar avatar-sm avatar-icon avatar-info me-3">
                <span class="initial-wrap rounded-8"><span class="svg-icon"><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-users" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    <path d="M21 21v-2a4 4 0 0 0 -3 -3.85"></path>
                </svg></span></span>
            </div>
            <div class="flex-wrap flex-1 d-flex justify-content-between">
                <div>
                    <div class="pg-subtitle">
                        Overview
                    </div>
                    <h5 class="pg-title fs-5">Clients Management</h5>
                </div>
                <div class="pg-header-action-wrap position-relative">
                    <div class="d-md-flex d-none ms-auto align-items-center">
                        <button class="btn btn-custom btn-white text-primary btn-floating rounded-8 ms-3" data-bs-toggle="modal" data-bs-target="#createClientModal">
                            <span>
                                <span class="bg-white shadow-xl icon rounded-8">
                                    <span class="svg-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon-tabler icon-tabler-plus" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <line x1="12" y1="5" x2="12" y2="19"></line>
                                            <line x1="5" y1="12" x2="19" y2="12"></line>
                                        </svg>
                                    </span>
                                </span>
                                <span class="fs-7">
                                        Add New Client
                                </span>
                            </span>
                        </button>
                        {{-- <button class="btn btn-custom btn-white text-primary btn-floating rounded-8 ms-3" data-bs-toggle="modal" data-bs-target="#uploadExcelModal">
                            <span>
                                <span class="bg-white shadow-xl icon rounded-8">
                                    <span class="svg-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon-tabler icon-tabler-upload" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2"></path>
                                            <polyline points="7 9 12 4 17 9"></polyline>
                                            <line x1="12" y1="4" x2="12" y2="16"></line>
                                        </svg>
                                    </span>
                                </span>
                                <span class="fs-7">Bulk Upload</span>
                            </span>
                        </button> --}}
                    </div>
                </div>
            </div>
        </div>
        <ul class="mt-3 nav nav-tabs nav-icon nav-light">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#tab_boards">
                    <span class="nav-icon-wrap"><span class="svg-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-id" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                            <rect x="3" y="4" width="18" height="16" rx="3"></rect>
                            <circle cx="9" cy="10" r="2"></circle>
                            <line x1="15" y1="8" x2="17" y2="8"></line>
                            <line x1="15" y1="12" x2="17" y2="12"></line>
                            <line x1="7" y1="16" x2="17" y2="16"></line>
                        </svg>
                    </span></span>
                    <span class="nav-link-text">All Clients</span>
                </a>
            </li>
            {{-- <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab_team">
                    <span class="nav-icon-wrap"><span class="svg-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-users" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                            <path d="M21 21v-2a4 4 0 0 0 -3 -3.85"></path>
                        </svg>
                    </span></span>
                    <span class="nav-link-text">Team Members</span>
                </a>
            </li> --}}
        </ul>
    </div>
</header>
