<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasShow{{$client->id}}" aria-labelledby="offcanvasShowLabel" style="width:800px;">
    <div class="offcanvas-header">
        <h5 id="offcanvasShowLabel" class="mb-0">Client Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div class="mb-4 d-flex align-items-center">
            <div class="avatar avatar-sm avatar-primary avatar-rounded me-5">
                <span class="initial-wrap">
                    {{ strtoupper(substr($client->name, 0, 1)) }}
                </span>
            </div>
            <div>
                <h4 class="mb-0">{{ $client->name }}</h4>
                <p class="mb-0 text-muted">{{ $client->title ?? 'No title provided' }}</p>
                <div class="mt-1">
                    @if($client->is_active)
                        <span class="badge badge-soft-success">Active</span>
                    @else
                        <span class="badge badge-soft-danger">Inactive</span>
                    @endif
                </div>
            </div>
        </div>
        <div class="mb-3">
            <ul class="nav nav-tabs nav-line-tabs nav-light">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="tab" href="#info{{$client->id}}">
                        <i class="ri-information-line me-2"></i>Info
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#services{{$client->id}}">
                        <i class="ri-service-line me-2"></i>Services
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#portfolio{{$client->id}}">
                        <i class="ri-gallery-line me-2"></i>Portfolio
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#deals{{$client->id}}">
                        <i class="ri-exchange-dollar-line me-2"></i>Deals
                    </a>
                </li>
            </ul>
        </div>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="info{{$client->id}}">
                <div class="mb-3 card card-border">
                    <div class="card-header card-header-action">
                        <h6 class="mb-0"><i class="ri-user-3-line me-2"></i>Basic Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">Name</label>
                                <p class="mb-0">{{ $client->name }}</p>
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">Title</label>
                                <p class="mb-0">{{ $client->title ?? 'N/A' }}</p>
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">Email</label>
                                <p class="mb-0">{{ $client->email }}</p>
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">Phone</label>
                                <p class="mb-0">{{ $client->phone ?? 'N/A' }}</p>
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">Company Size</label>
                                <p class="mb-0">{{ $client->company_size ?? 'N/A' }}</p>
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">Account Created</label>
                                <p class="mb-0">{{ $client->created_at ? $client->created_at->format('M d, Y') : 'N/A' }}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3 card card-border">
                    <div class="card-header card-header-action">
                        <h6 class="mb-0"><i class="ri-map-pin-2-line me-2"></i>Address Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="mb-3 col-sm-12">
                                <label class="form-label text-muted small">Address</label>
                                <p class="mb-0">{{ $client->address ?? 'N/A' }}</p>
                            </div>
                            <div class="mb-3 col-sm-4">
                                <label class="form-label text-muted small">Country</label>
                                <p class="mb-0">{{ $client->country ?? 'N/A' }}</p>
                            </div>
                            <div class="mb-3 col-sm-4">
                                <label class="form-label text-muted small">City</label>
                                <p class="mb-0">{{ $client->city ?? 'N/A' }}</p>
                            </div>
                            <div class="mb-3 col-sm-4">
                                <label class="form-label text-muted small">ZIP Code</label>
                                <p class="mb-0">{{ $client->zip ?? 'N/A' }}</p>
                            </div>
                            @if($client->map)
                            <div class="mb-3 col-sm-12">
                                <label class="form-label text-muted small">Map Location</label>
                                <div class="mt-2 map-container" style="height: 200px;">
                                    {!! $client->map !!}
                                </div>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
                <div class="mb-3 card card-border">
                    <div class="card-header card-header-action">
                        <h6 class="mb-0"><i class="ri-global-line me-2"></i>Online Presence</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="mb-3 col-sm-12">
                                <label class="form-label text-muted small">Website</label>
                                @if($client->website)
                                    <p class="mb-0"><a href="{{ $client->website }}" target="_blank">{{ $client->website }}</a></p>
                                @else
                                    <p class="mb-0">N/A</p>
                                @endif
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">Facebook</label>
                                @if($client->facebook)
                                    <p class="mb-0"><a href="{{ $client->facebook }}" target="_blank">{{ $client->facebook }}</a></p>
                                @else
                                    <p class="mb-0">N/A</p>
                                @endif
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">LinkedIn</label>
                                @if($client->linkedin)
                                    <p class="mb-0"><a href="{{ $client->linkedin }}" target="_blank">{{ $client->linkedin }}</a></p>
                                @else
                                    <p class="mb-0">N/A</p>
                                @endif
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">Instagram</label>
                                @if($client->instagram)
                                    <p class="mb-0"><a href="{{ $client->instagram }}" target="_blank">{{ $client->instagram }}</a></p>
                                @else
                                    <p class="mb-0">N/A</p>
                                @endif
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label text-muted small">YouTube</label>
                                @if($client->youtube)
                                    <p class="mb-0"><a href="{{ $client->youtube }}" target="_blank">{{ $client->youtube }}</a></p>
                                @else
                                    <p class="mb-0">N/A</p>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="services{{$client->id}}">
                <div class="card card-border">
                    <div class="card-header card-header-action">
                        <h6 class="mb-0">Client Services</h6>
                        <div class="card-action-wrap">
                            <button class="btn btn-xs btn-icon btn-flush-dark btn-rounded flush-soft-hover"
                                    data-bs-toggle="tooltip"
                                    data-bs-placement="top"
                                    title=""
                                    data-bs-original-title="Add Service">
                                <span class="icon"><span class="feather-icon"><i data-feather="plus"></i></span></span>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        @if(isset($client->services) && count($client->services) > 0)
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Service</th>
                                            <th>Status</th>
                                            <th>Start Date</th>
                                            <th>End Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($client->services as $service)
                                            <tr>
                                                <td>{{ $service->name }}</td>
                                                <td>
                                                    <span class="badge bg-{{ $service->status == 'active' ? 'success' : 'warning' }}-light-5 text-{{ $service->status == 'active' ? 'success' : 'warning' }}">
                                                        {{ ucfirst($service->status) }}
                                                    </span>
                                                </td>
                                                <td>{{ $service->start_date }}</td>
                                                <td>{{ $service->end_date ?: 'Ongoing' }}</td>
                                                <td>
                                                    <div class="d-flex">
                                                        <button class="btn btn-icon btn-sm btn-flush-dark btn-rounded flush-soft-hover">
                                                            <span class="icon"><span class="feather-icon"><i data-feather="edit-2"></i></span></span>
                                                        </button>
                                                        <button class="btn btn-icon btn-sm btn-flush-dark btn-rounded flush-soft-hover">
                                                            <span class="icon"><span class="feather-icon"><i data-feather="trash-2"></i></span></span>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <div class="py-4 d-flex flex-column align-items-center justify-content-center">
                                <div class="mb-3 avatar avatar-icon avatar-soft-primary">
                                    <span class="initial-wrap">
                                        <i class="ri-service-line"></i>
                                    </span>
                                </div>
                                <p class="mb-0 text-center">No services have been added for this client yet.</p>
                                <button class="mt-3 btn btn-soft-primary btn-sm">
                                    <span class="feather-icon me-1"><i data-feather="plus"></i></span> Add Service
                                </button>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="portfolio{{$client->id}}">
                <div class="card card-border">
                    <div class="card-header card-header-action">
                        <h6 class="mb-0">Client Portfolio</h6>
                    </div>
                    <div class="card-body">
                        <div class="py-4 d-flex flex-column align-items-center justify-content-center">
                            <div class="mb-3 avatar avatar-icon avatar-soft-warning">
                                <span class="initial-wrap">
                                    <i class="ri-gallery-line"></i>
                                </span>
                            </div>
                            <p class="mb-0 text-center">Portfolio management feature coming soon.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="deals{{$client->id}}">
                <div class="card card-border">
                    <div class="card-header card-header-action">
                        <h6 class="mb-0">Client Deals</h6>
                    </div>
                    <div class="card-body">
                        <div class="py-4 d-flex flex-column align-items-center justify-content-center">
                            <div class="mb-3 avatar avatar-icon avatar-soft-success">
                                <span class="initial-wrap">
                                    <i class="ri-exchange-dollar-line"></i>
                                </span>
                            </div>
                            <p class="mb-0 text-center">Deals management feature coming soon.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-4 d-flex justify-content-between">
            <button class="btn btn-soft-secondary" data-bs-dismiss="offcanvas">Close</button>
            <div>
                <button class="btn btn-soft-primary me-2" data-bs-toggle="offcanvas" data-bs-target="#offcanvasUpdate{{$client->id}}" data-bs-dismiss="offcanvas">
                    <i class="ri-edit-2-line me-1"></i> Edit
                </button>
                <button class="btn btn-soft-danger" data-bs-toggle="modal" data-bs-target="#deleteModal{{$client->id}}" data-bs-dismiss="offcanvas">
                    <i class="ri-delete-bin-line me-1"></i> Delete
                </button>
            </div>
        </div>
    </div>
</div>
