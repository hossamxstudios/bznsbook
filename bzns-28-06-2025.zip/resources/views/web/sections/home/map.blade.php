
        <section class="py-5 mt-5 bg-dark" data-bs-theme="dark">
            <div class="container pt-2 py-sm-3 py-md-4 py-lg-5 my-xxl-3">
              <div class="row pt-lg-2 pt-xl-3">
                <div class="col-md-6">
                  <h2 class="h1 pe-xxl-5 me-xl-4 mb-md-0">Our <span class="text-warning">Partners </span> spread all over the world. Get access  to the BZNS BOOK from anywhere</h2>
                </div>
                <div class="col-md-6 col-xl-5 offset-xl-1">
                  <p class="mb-0 text-body fs-xl">Our Partners are a key component of our global infrastructure, providing reliable and scalable services to customers around the world. We offer a highly distributed and resilient platform that can support the most demanding workloads.</p>
                </div>
              </div>
              <div class="pt-5 mt-sm-2 mt-md-3 mt-lg-4 mt-xl-5">
                <img src="assets/img/landing/saas-5/map.png" alt="Map">
              </div>
            </div>
          </section>
