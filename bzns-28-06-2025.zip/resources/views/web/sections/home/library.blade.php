<section class="container pb-5">
    <div class="pt-5 mt-1 text-center">
        <a href="javascript:void(0);" class="px-3 py-1 border border-opacity-50 d-inline-flex align-items-center fs-sm fw-semibold text-decoration-none border-primary rounded-pill">
            <span class="text-gradient-primary lh-lg">Bzns Library v2.0</span>
            <i class="bx bx-right-arrow-alt text-gradient-primary fs-lg ms-2 me-n1"></i>
        </a>
        <h1 class="pt-3 mt-3 mb-5 display-4">Powerful Library to serve your business needs</h1>
    </div>
    <div class="swiper" data-swiper-options='{"slidesPerView": 1,"spaceBetween": 24,"pagination": {"el": ".swiper-pagination","clickable": true},"breakpoints": {"560": {"slidesPerView": 2},"960": {"slidesPerView": 3}}}'>
        <div class="swiper-wrapper">
            <!-- Item -->
            <div class="swiper-slide">
                <a href="{{ route('pages.library.business-guide') }}" class="overflow-hidden card-portfolio position-relative d-block rounded-3">
                    <span class="top-0 position-absolute start-0 w-100 h-100 zindex-1"
                        style="background: linear-gradient(180deg, rgba(17, 24, 39, 0.00) 35.56%, #111827 95.3%);"></span>
                    <div class="bottom-0 p-4 position-absolute w-100 zindex-2">
                        <div class="px-md-3">
                            <h3 class="mb-0 text-white h4">Business Guide</h3>
                            <div class="card-portfolio-meta d-flex align-items-center justify-content-between">
                                <span class="text-white opacity-70 fs-xs text-truncate pe-3">Business guides for entrepreneurs</span>
                                <i class="bx bx-right-arrow-circle fs-3 text-gradient-primary"></i>
                            </div>
                        </div>
                    </div>
                    <div class="card-img">
                        <img src={{ asset("business.jpg") }} alt="Business Guide">
                    </div>
                </a>
            </div>
             <!-- Item -->
             <div class="swiper-slide">
                <a href="{{ route('pages.library.shipping-guide') }}" class="overflow-hidden card-portfolio position-relative d-block rounded-3">
                    <span class="top-0 position-absolute start-0 w-100 h-100 zindex-1"
                        style="background: linear-gradient(180deg, rgba(17, 24, 39, 0.00) 35.56%, #111827 95.3%);"></span>
                    <div class="bottom-0 p-4 position-absolute w-100 zindex-2">
                        <div class="px-md-3">
                            <h3 class="mb-0 text-white h4">Shipping Guide</h3>
                            <div class="card-portfolio-meta d-flex align-items-center justify-content-between">
                                <span class="text-white opacity-70 fs-xs text-truncate pe-3">Shipping guide for entrepreneurs</span>
                                <i class="bx bx-right-arrow-circle fs-3 text-gradient-primary"></i>
                            </div>
                        </div>
                    </div>
                    <div class="card-img">
                        <img src={{ asset("shipping.jpg") }} alt="Shipping Guide">
                    </div>
                </a>
            </div>
             <!-- Item -->
             <div class="swiper-slide">
                <a href="{{ route('pages.library.middle-east') }}" class="overflow-hidden card-portfolio position-relative d-block rounded-3">
                    <span class="top-0 position-absolute start-0 w-100 h-100 zindex-1"
                        style="background: linear-gradient(180deg, rgba(17, 24, 39, 0.00) 35.56%, #111827 95.3%);"></span>
                    <div class="bottom-0 p-4 position-absolute w-100 zindex-2">
                        <div class="px-md-3">
                            <h3 class="mb-0 text-white h4">Middle East Investment Guide</h3>
                            <div class="card-portfolio-meta d-flex align-items-center justify-content-between">
                                <span class="text-white opacity-70 fs-xs text-truncate pe-3">Middle East Investment Guide for entrepreneurs</span>
                                <i class="bx bx-right-arrow-circle fs-3 text-gradient-primary"></i>
                            </div>
                        </div>
                    </div>
                    <div class="card-img">
                        <img src={{ asset("middle-east.jpg") }} alt="Middle East Investment Guide">
                    </div>
                </a>
            </div>
        </div>
        <!-- Pagination (bullets) -->
        <div class="bottom-0 pt-2 mt-4 swiper-pagination position-relative pt-md-3"></div>
    </div>
</section>
