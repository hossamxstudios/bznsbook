<!doctype html>
@include('web.main.html')
<head>
    <meta charset="utf-8" />
    <title>Business Growth Strategy Guide | Bzns</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('web.main.meta')
    <style>
        /* Custom styles for the business guide */
        .guide-header {
            background: linear-gradient(135deg, #3e3e3e 0%, #1a1a1a 100%);
            padding: 60px 0;
            margin-bottom: 0;
            position: relative;
        }
        .guide-title {
            font-weight: 700;
            letter-spacing: -0.5px;
            margin-bottom: 1rem;
        }
        .guide-subtitle {
            font-weight: 300;
            opacity: 0.9;
            margin-bottom: 1.5rem;
        }
        .guide-content {
            padding: 50px 0;
            background: #fff;
            position: relative;
        }
        .guide-content .container {
            position: relative;
        }
        .content-block {
            margin-bottom: 2rem;
            line-height: 1.7;
        }
        .content-visible {
            border-bottom: 1px solid #eee;
            padding-bottom: 2rem;
            margin-bottom: 2rem;
        }
        .content-blurred {
            position: relative;
            filter: blur(4px);
            user-select: none;
            pointer-events: none;
            opacity: 0.7;
        }
        .content-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.8) 70%, rgba(255,255,255,1) 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 10;
            padding-top: 100px;
        }
        .subscribe-card {
            background-color: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 500px;
            width: 90%;
            transform: translateY(-366px);
        }
        .subscribe-btn {
            background: #3e3e3e;
            color: white;
            font-weight: 600;
            border-radius: 50px;
            padding: 12px 35px;
            font-size: 16px;
            transition: all 0.3s ease;
            border: 2px solid #3e3e3e;
            display: inline-block;
            margin-top: 15px;
        }
        .subscribe-btn:hover {
            background: #555;
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        .section-title {
            font-weight: 700;
            margin-bottom: 1rem;
            color: #333;
            position: relative;
            display: inline-block;
        }
        .section-title:after {
            content: '';
            display: block;
            width: 70%;
            height: 3px;
            background: #3e3e3e;
            margin-top: 5px;
        }
        .list-styled {
            padding-left: 20px;
        }
        .list-styled li {
            margin-bottom: 0.75rem;
            position: relative;
            padding-left: 10px;
        }
        .list-styled li:before {
            content: '•';
            color: #3e3e3e;
            font-weight: bold;
            display: inline-block;
            width: 1em;
            margin-left: -1em;
        }
        .featured-badge {
            display: inline-block;
            background-color: #f8f9fa;
            padding: 5px 15px;
            border-radius: 50px;
            font-weight: 500;
            font-size: 12px;
            color: #3e3e3e;
            border: 1px solid #eee;
            margin-bottom: 1rem;
        }
        .highlight-box {
            background-color: #f8f9fa;
            border-left: 4px solid #3e3e3e;
            padding: 20px;
            margin: 1.5rem 0;
            border-radius: 0 5px 5px 0;
        }
        .highlight-box p:last-child {
            margin-bottom: 0;
        }
    </style>
</head>
<body>
    <main class="page-wrapper">
        @include('web.main.navbar')

        <!-- Guide Header Section -->
        {{-- <section class="text-white guide-header">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="text-center col-lg-8">
                        <span class="bg-white featured-badge text-dark">PREMIUM BUSINESS GUIDE</span>
                        <h1 class="guide-title">Ultimate Business Growth Strategy Guide 2025</h1>
                        <p class="guide-subtitle">Master proven strategies to scale your business, optimize operations, and increase revenue in today's competitive market</p>
                    </div>
                </div>
            </div>
        </section> --}}

        <!-- Guide Content Section -->
        <section class="guide-content">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <!-- Introduction - Visible Content -->
                        <div class="content-block content-visible">
                            <h2 class="section-title">Introduction to Business Growth</h2>
                            <p>
                                In today's rapidly evolving business landscape, companies must continually adapt and innovate to maintain competitive advantage. This comprehensive guide explores proven strategies for sustainable business growth across various industries and markets.
                            </p>
                        </div>

                        <!-- Strategy Section - Blurred Content -->
                        <div class="content-block content-blurred">
                            <h2 class="section-title">Key Growth Strategies for 2025</h2>
                            <p>
                                The business landscape of 2025 presents unique challenges and opportunities driven by technological advancement, changing consumer behaviors, and economic shifts. Organizations that thrive will be those that successfully implement the following strategic frameworks:
                            </p>

                            <h3>1. Market Penetration and Expansion</h3>
                            <p>
                                Deepening your presence in existing markets often represents the lowest-risk growth path. Consider these approaches:
                            </p>
                            <div class="highlight-box">
                                <p><strong>Case Study:</strong> How Company XYZ increased market share by 32% in 12 months through targeted micro-segmentation and personalized marketing automation.</p>
                            </div>

                            <h3>2. Digital Transformation Strategy</h3>
                            <p>
                                Digital transformation isn't just about adopting new technologies—it's about reimagining business processes and customer experiences. A successful digital transformation strategy includes:
                            </p>
                            <ul class="list-styled">
                                <li>Comprehensive audit of current technology infrastructure and capabilities</li>
                                <li>Clear prioritization of initiatives based on business impact and implementation feasibility</li>
                                <li>Development of digital-first customer journeys that enhance satisfaction and loyalty</li>
                                <li>Implementation of data analytics frameworks to enable data-driven decision making</li>
                                <li>Cultural transformation to foster innovation and agility across the organization</li>
                            </ul>

                            <h3>3. Operational Excellence</h3>
                            <p>
                                Streamlining operations is essential for scaling efficiently. Focus on these areas:
                            </p>
                            <ul class="list-styled">
                                <li>Process standardization and documentation</li>
                                <li>Strategic automation of repetitive tasks</li>
                                <li>Implementation of continuous improvement methodologies</li>
                                <li>Development of key performance indicators aligned with strategic objectives</li>
                                <li>Regular review cycles to identify and address operational bottlenecks</li>
                            </ul>
                        </div>

                        <!-- Subscription Overlay -->
                        <div class="content-overlay">
                            <div class="subscribe-card">
                                <h3>Access the Full Business Guide</h3>
                                <p class="mb-4">Unlock our complete library of premium business content, strategic frameworks, and actionable insights to accelerate your business growth.</p>
                                <a href="#" class="subscribe-btn">Subscribe Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        @include('web.main.footer')
    </main>
    @include('web.main.scripts')
</body>
