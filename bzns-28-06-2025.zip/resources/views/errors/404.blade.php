<!doctype html>
@include('admin.main.html')

<head>
    <meta charset="utf-8" />
    <title> BZNSBOOKHR </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('admin.main.meta')
</head>

<body>
    <div class="rbt-error-area bg-gradient-11 rbt-section-gap" style="background: linear-gradient(180deg, #f9bfbf 0%, #FFFFFF 100%) !important;">
        <div class="error-area">
            <div class="container">
                <div class="row justify-content-center text-center">
                    <div class="col-10">
                        <h1 class="title">404!</h1>
                        <h3 class="sub-title">Page not found</h3>
                        <p>The page you were looking for could not be found.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
