<div class="hk-footer">
    <footer class="container-xxl footer">
        <div class="row h-auto">
            <div class="col-xl-4">
                <p class="footer-text"><span class="copy-text">BZNSBOOKHR © 2025 All rights reserved.</span> <a href="#" class="" target="_blank">Privacy Policy</a> </p>
            </div>
            <div class="col-xl-4 d-flex justify-content-center align-items-center">
                <h6 class="px-3 m-0"><span class="copy-text">Powered By   </h6>
                <img class="brand-img d-inline-block img-fluid py-2" style="width: 152px" src="{{ URL::asset('crmlogo.png') }}" alt="brand" />
            </div>
            <div class="col-xl-4">
                {{-- <div class="footer-social-btn-wrap">
                    <a href="#" class="btn btn-icon btn-rounded btn-soft-light btn-sm"><span class="icon"><i class="fab fa-facebook"></i></span></a>
                    <a href="#" class="btn btn-icon btn-rounded btn-soft-light btn-sm"><span class="icon"><i class="fab fa-linkedin"></i></span></a>
                    <a href="#" class="btn btn-icon btn-rounded btn-soft-light btn-sm"><span class="icon"><i class="fab fa-google"></i></span></a>
                    <a href="#" class="btn btn-icon btn-rounded btn-soft-light btn-sm"><span class="icon"><i class="fab fa-twitter"></i></span></a>
                </div> --}}
            </div>
        </div>
    </footer>
</div>
